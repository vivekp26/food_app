import 'package:flutter/material.dart';
import 'package:food_delivery_app/DrawerScreens/AddressScreen.dart';
import 'package:food_delivery_app/HomeScreens/HomePage.dart';

class AddAddressScreen extends StatefulWidget {
  const AddAddressScreen({super.key});

  @override
  State<AddAddressScreen> createState() => _AddAddressScreenState();
}

class _AddAddressScreenState extends State<AddAddressScreen> {
  List labelText = [
    'Home',
    'Work',
    'Other'
  ];
  int currentIndex = 0;
  @override
  Widget build(BuildContext context) {
    return Scaffold(
      body: SizedBox(
        height: MediaQuery.of(context).size.height,
        child: SingleChildScrollView(
          child: Column(crossAxisAlignment: CrossAxisAlignment.start,
            children: [
              Container(
                width: MediaQuery.of(context).size.width,
                constraints: const BoxConstraints(minHeight: 295),
                decoration: const BoxDecoration(
                  color: Color(0xffD0D9E1),
                    borderRadius: BorderRadius.only(topLeft: Radius.circular(20),topRight: Radius.circular(20))),
                child: Padding(
                  padding: const EdgeInsets.symmetric(vertical: 50,horizontal: 24),
                  child: Column(
                    crossAxisAlignment: CrossAxisAlignment.start,
                    children: [
                      InkWell(onTap: (){
                        Navigator.push(context, MaterialPageRoute(builder: (context) => AddressScreen(),));
                      },
                        child: Container(
                          constraints: const BoxConstraints(minHeight: 45,minWidth: 53),
                          decoration: const BoxDecoration(
                            shape: BoxShape.circle,
                            color: Color(0xff32343E)
                          ),child: const Icon(Icons.arrow_back_ios_outlined,color: Colors.white,),
                        ),
                      ),
                      const SizedBox(height: 62,),
                      Center(
                        child: Container(
                          constraints: const BoxConstraints(minWidth: 30,minHeight: 30),
                          decoration: const BoxDecoration(
                            boxShadow: [BoxShadow(blurRadius: 10,color: Color(0xffF6916D33),spreadRadius: 1  )],
                            // color: Color(0xffF6916D33),
                            shape: BoxShape.circle
                          ),child: const Icon(Icons.circle,color: Color(0xffFB6D3A),),
                        ),
                      )
                    ],
                  ),
                ),
              ),
              const SizedBox(
                height: 34,
              ),
              Padding(
                padding: const EdgeInsets.symmetric(horizontal: 24.0),
                child: Column(crossAxisAlignment: CrossAxisAlignment.start,
                  children: [
                    const Text(
                      'ADDRESS',
                      style: TextStyle(fontSize: 14, fontWeight: FontWeight.w400, color: Color(0xff32343E)),
                    ),
                    const SizedBox(
                      height: 8,
                    ),
                    TextFormField(
                      decoration: InputDecoration(
                          hintText: '3235 Royal Ln. mesa, new jersy 34567',
                          prefixIcon: const Icon(Icons.location_on_outlined,color: Color(0xff6B6E82),),
                          hintStyle: const TextStyle(fontSize: 14, color: Color(0xff6B6E82), fontWeight: FontWeight.w400),
                          fillColor: const Color(0xffF0F5FA),
                          filled: true,
                          contentPadding: const EdgeInsets.all(20),
                          border: OutlineInputBorder(borderSide: BorderSide.none, borderRadius: BorderRadius.circular(10))),
                    ),
                    const SizedBox(height: 24,),
                    Row(
                      mainAxisAlignment: MainAxisAlignment.spaceBetween,
                      children: [
                        Column(crossAxisAlignment: CrossAxisAlignment.start,
                          children: [
                            const Text('STREET'),
                            const SizedBox(
                              height: 8,
                            ),
                            SizedBox(width: 156,
                              child: TextFormField(
                                decoration: InputDecoration(
                                    hintText: 'hason nagar',
                                    prefixIcon: const Icon(Icons.location_on_outlined,color: Color(0xff6B6E82),),
                                    hintStyle: const TextStyle(fontSize: 14, color: Color(0xff6B6E82), fontWeight: FontWeight.w400),
                                    fillColor: const Color(0xffF0F5FA),
                                    filled: true,
                                    contentPadding: const EdgeInsets.all(20),
                                    border: OutlineInputBorder(borderSide: BorderSide.none, borderRadius: BorderRadius.circular(10))),
                              ),
                            ),
                          ],
                        ),
                        Column(crossAxisAlignment: CrossAxisAlignment.start,
                          children: [
                            const Text('POST CODE'),
                             const SizedBox(
                              height: 8,
                            ),
                            SizedBox(
                              width: 156,
                              child: TextFormField(
                                decoration: InputDecoration(
                                    hintText: '34567',
                                    prefixIcon: const Icon(Icons.location_on_outlined,color: Color(0xff6B6E82),),
                                    hintStyle: const TextStyle(fontSize: 14, color: Color(0xff6B6E82), fontWeight: FontWeight.w400),
                                    fillColor: const Color(0xffF0F5FA),
                                    filled: true,
                                    contentPadding: const EdgeInsets.all(20),
                                    border: OutlineInputBorder(borderSide: BorderSide.none, borderRadius: BorderRadius.circular(10))),
                              ),
                            ),
                          ],
                        ),
                      ],
                    ),
                    const SizedBox(height: 24,),
                    const Text(
                      'APPARTMENT',
                      style: TextStyle(fontSize: 14, fontWeight: FontWeight.w400, color: Color(0xff32343E)),
                    ),
                    const SizedBox(
                      height: 8,
                    ),
                    TextFormField(
                      decoration: InputDecoration(
                          hintText: '345',
                          prefixIcon: const Icon(Icons.location_on_outlined,color: Color(0xff6B6E82),),
                          hintStyle: const TextStyle(fontSize: 14, color: Color(0xff6B6E82), fontWeight: FontWeight.w400),
                          fillColor: const Color(0xffF0F5FA),
                          filled: true,
                          contentPadding: const EdgeInsets.all(20),
                          border: OutlineInputBorder(borderSide: BorderSide.none, borderRadius: BorderRadius.circular(10))),
                    ),
                    const SizedBox(height: 24,),
                    const Text(
                      'LABEL AS',
                      style: TextStyle(fontSize: 14, fontWeight: FontWeight.w400, color: Color(0xff32343E)),
                    ),
                    const SizedBox(height: 12,),
                    SizedBox(height: 45,
                      child: ListView.separated(shrinkWrap: true,scrollDirection: Axis.horizontal,itemCount: labelText.length,separatorBuilder: (context, index) {
                        return const SizedBox(width: 10,);
                      },itemBuilder: (context, index) {
                        return InkWell(onTap: (){
                          setState(() {
                            currentIndex==index;
                          });
                        },
                          child: Container(
                            constraints: const BoxConstraints(minHeight: 45,minWidth: 94),
                            decoration: BoxDecoration(
                              color: currentIndex==index?const Color(0xffF58D1D): const Color(0xffF0F5FA),
                                borderRadius: BorderRadius.circular(30)
                            ),child: Center(
                              child: Text(labelText[index],style: TextStyle(fontSize: 14, fontWeight: FontWeight.w400, color:currentIndex == index
                              ? Colors.white
                                  : Colors.black, ),
                          ),
                            ),
                          ),
                        );
                      },
                      ),
                    ),
                    const SizedBox(height: 32,),
                    InkWell(onTap: (){
                      Navigator.push(context, MaterialPageRoute(builder: (context) => const HomePage()));
                    },
                      child: Container(
                        width: MediaQuery.of(context).size.width,
                        constraints: const BoxConstraints(minHeight: 62),
                        decoration: BoxDecoration(
                            borderRadius: BorderRadius.circular(20),
                            color: const Color(0xffFF7622)
                        ),child: const Center(child: Text('SAVE LOCATION',style: TextStyle(fontSize: 16,fontWeight: FontWeight.w700,color: Colors.white),)),
                      ),
                    )
                  ],
                ),
              ),
            ],
          ),
        ),
      ),
    );
  }
}
