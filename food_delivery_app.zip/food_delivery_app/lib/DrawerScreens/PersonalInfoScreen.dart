import 'package:flutter/material.dart';
import 'package:food_delivery_app/DrawerScreens/EditProfileScreen.dart';
import 'package:food_delivery_app/HomeScreens/HomePage.dart';

class PersonalInfoScreen extends StatefulWidget {
  const PersonalInfoScreen({super.key});

  @override
  State<PersonalInfoScreen> createState() => _PersonalInfoScreenState();
}

class _PersonalInfoScreenState extends State<PersonalInfoScreen> {
  final GlobalKey<ScaffoldState> _scaffoldKey = GlobalKey<ScaffoldState>();
  @override
  Widget build(BuildContext context) {
    return Scaffold(
      key: _scaffoldKey,
      body: SafeArea(
        child: Padding(
          padding: const EdgeInsets.symmetric(horizontal: 24),
          child: Column(
            children: [SizedBox(height: 24,),
              Row(
                mainAxisAlignment: MainAxisAlignment.spaceBetween,
                children: [
                  Row(
                    children: [
                      InkWell(onTap: (){
                        // _scaffoldKey.currentState?.openEndDrawer();
                        },
                        child: Container(
                            constraints: BoxConstraints(minHeight: 45,minWidth: 45),
                          //   height: 45,
                          //   width: 45,
                            decoration: BoxDecoration(color: Color(0xffECF0F4), shape: BoxShape.circle),
                            child: IconButton(
                                onPressed: () {
                                  Navigator.push(context, MaterialPageRoute(builder: (context) => HomePage(),));

                                },icon: Icon(Icons.arrow_back_ios_outlined))),
                      ),
                      SizedBox(
                        width: 16,
                      ),
                      Text(
                        'Personal Info',
                        style: TextStyle(color: Color(0xff181C2E), fontSize: 17, fontWeight: FontWeight.w400),
                      ),
                    ],
                  ),
                  TextButton(
                    child: Text(
                      'EDIT',style: TextStyle(color: Color(0xffFF7622), fontSize: 17, fontWeight: FontWeight.w400),

                      // color: Colors.white,
                    ),
                    onPressed: () {
                      Navigator.push(context, MaterialPageRoute(builder: (context) => EditProfileScreen(),));
                    },
                  ),
                ],
              ),
              SizedBox(height: 24,),
              Row(
                children: [
                  Container(
                    constraints: BoxConstraints(minHeight: 100, minWidth: 100),
                    decoration: BoxDecoration(shape: BoxShape.circle, color: Color(0xffFFBF6D),),
                    child: Icon(Icons.person),
                  ),
                  Padding(
                    padding: const EdgeInsets.symmetric(horizontal: 15),
                    child: Column(
                      children: [
                        Text(
                          'Vishal Khadok',
                          overflow: TextOverflow.ellipsis,
                          style: TextStyle(fontSize: 20, color: Color(0xff32343E), fontWeight: FontWeight.w700),
                        ),
                        SizedBox(
                          height: 8,
                        ),
                        Text(
                          'I love fast food',
                          overflow: TextOverflow.ellipsis,
                          style: TextStyle(fontSize: 14, color: Color(0xffA0A5BA), fontWeight: FontWeight.w400),
                        ),
                      ],
                    ),
                  )
                ],
              ),
              SizedBox(height: 32,),
              Container(
                width: MediaQuery.of(context).size.width,
                constraints: BoxConstraints(minHeight: 200),
                decoration: BoxDecoration(
                    color: Color(0xffF6F8FA),
                    borderRadius: BorderRadius.circular(20)),
                child: Column(
                  children: [
                    ListTile(
                      leading: Container(
                        constraints: BoxConstraints(minHeight: 40,minWidth: 40),
                        decoration: BoxDecoration(
                          shape: BoxShape.circle,
                        ),child: Icon(
                        Icons.person,
                        color: Color(0xffFB6F3D),
                      ),
                      ),
                      title: Text('FULL NAME',style: TextStyle(fontSize: 14,color: Color(0xff32343E),fontWeight: FontWeight.w400)),
                      subtitle: Text('Vishal Khadok',style: TextStyle(fontSize: 14,color: Color(0xff32343E),fontWeight: FontWeight.w400)),
                    ),
                    ListTile(
                      leading: Container(
                        constraints: BoxConstraints(minHeight: 40,minWidth: 40),
                        decoration: BoxDecoration(
                          shape: BoxShape.circle,
                        ),child: Icon(
                        Icons.email_outlined,
                        color: Color(0xff413DFB),
                      ),
                      ),
                      title: Text('EMAIL',style: TextStyle(fontSize: 14,color: Color(0xff32343E),fontWeight: FontWeight.w400)),
                      subtitle: Text('hello@halallab.co',style: TextStyle(fontSize: 14,color: Color(0xff32343E),fontWeight: FontWeight.w400)),
                    ),
                    ListTile(
                      leading: Container(
                        constraints: BoxConstraints(minHeight: 40,minWidth: 40),
                        decoration: BoxDecoration(
                          shape: BoxShape.circle,
                        ),child: Icon(
                        Icons.local_phone_outlined,
                        color: Color(0xff369BFF),
                      ),
                      ),
                      title: Text('Phone Number',style: TextStyle(fontSize: 14,color: Color(0xff32343E),fontWeight: FontWeight.w400)),
                      subtitle: Text('408-841-0926',style: TextStyle(fontSize: 14,color: Color(0xff32343E),fontWeight: FontWeight.w400)),
                    ),
                  ],
                ),
              ),
            ],
          ),
        ),
      ),
    );
  }
}
