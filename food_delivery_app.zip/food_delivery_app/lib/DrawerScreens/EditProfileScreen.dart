
import 'dart:io';

import 'package:flutter/material.dart';
import 'package:food_delivery_app/DrawerScreens/PersonalInfoScreen.dart';
import 'package:food_delivery_app/HomeScreens/HomePage.dart';
import 'package:image_picker/image_picker.dart';

class EditProfileScreen extends StatefulWidget {
  const EditProfileScreen({super.key});

  @override
  State<EditProfileScreen> createState() => _EditProfileScreenState();
}

class _EditProfileScreenState extends State<EditProfileScreen> {
  final ImagePicker _picker = ImagePicker();
  XFile? _imageFile;
  void _getImage() async {
    try {
      final XFile? image = await _picker.pickImage(source: ImageSource.gallery);
      if(image !=null){
      setState(() {
        _imageFile = image;
      });
      }else{
        print('No image selected.');
      }
    } on Exception catch (e) {
      print('Error Picking image: $e');
    }
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      body: SafeArea(
        child: Padding(
          padding: const EdgeInsets.symmetric(horizontal: 24),
          child: SingleChildScrollView(
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [const SizedBox(height: 24,),
                Row(
                  children: [
                    Container(
                        constraints: const BoxConstraints(minHeight: 45,minWidth: 45),
                        // height: 45,
                        // width: 45,
                        decoration: const BoxDecoration(color: Color(0xffECF0F4), shape: BoxShape.circle),
                        child: IconButton(onPressed: () {
                          Navigator.push(context, MaterialPageRoute(builder: (context) => const PersonalInfoScreen(),));
                        }, icon: const Icon(Icons.arrow_back_ios_outlined))),
                    const SizedBox(
                      width: 16,
                    ),
                    const Text(
                      'Edit Profile',
                      style: TextStyle(color: Color(0xff181C2E), fontSize: 17, fontWeight: FontWeight.w400),
                    ),
                  ],
                ),
                const SizedBox(
                  height: 25,
                ),
                Stack(
                  children: [
                    Container(
                    constraints: const BoxConstraints(minWidth: 130, minHeight: 130),
                    decoration: BoxDecoration(
                        shape: BoxShape.circle,
                        color: const Color(0xffFFBF6D),
                        image: _imageFile != null
                            ? DecorationImage(
                                image: FileImage(File(_imageFile!.path)),
                                fit: BoxFit.cover,
                              )
                            : null),
                  ),
                  Positioned(bottom: 10,right:100,
                      child: CircleAvatar(
                        child: IconButton(style: const ButtonStyle(backgroundColor: MaterialStatePropertyAll(Color(0xffFF7622))),
                          onPressed: _getImage,
                          icon: const Icon(Icons.camera_alt_outlined,color: Colors.white,),
                        ),
                      )),
                ]),

                const SizedBox(
                  height: 30,
                ),
                const Text(
                  'FULL NAME',
                  style: TextStyle(fontSize: 14, fontWeight: FontWeight.w400, color: Color(0xff32343E)),
                ),
                const SizedBox(
                  height: 8,
                ),
                TextFormField(
                  decoration: InputDecoration(
                      hintText: 'Vishal Khadok',
                      hintStyle: const TextStyle(fontSize: 14, color: Color(0xff6B6E82), fontWeight: FontWeight.w400),
                      fillColor: const Color(0xffF0F5FA),
                      filled: true,
                      contentPadding: const EdgeInsets.all(20),
                      border: OutlineInputBorder(borderSide: BorderSide.none, borderRadius: BorderRadius.circular(10))),
                ),
                const SizedBox(
                  height: 24,
                ),
                const Text(
                  'EMAIL',
                  style: TextStyle(fontSize: 14, fontWeight: FontWeight.w400, color: Color(0xff32343E)),
                ),
                const SizedBox(
                  height: 8,
                ),
                TextFormField(
                  decoration: InputDecoration(
                      hintText: 'hello@halallab.co',
                      hintStyle: const TextStyle(fontSize: 14, color: Color(0xff6B6E82), fontWeight: FontWeight.w400),
                      fillColor: const Color(0xffF0F5FA),
                      filled: true,
                      contentPadding: const EdgeInsets.all(20),
                      border: OutlineInputBorder(borderSide: BorderSide.none, borderRadius: BorderRadius.circular(10))),
                ),
                const SizedBox(
                  height: 24,
                ),
                const Text(
                  'PHONE NUMBER',
                  style: TextStyle(fontSize: 14, fontWeight: FontWeight.w400, color: Color(0xff32343E)),
                ),
                const SizedBox(
                  height: 8,
                ),
                TextFormField(
                  decoration: InputDecoration(
                      hintText: '408-841-0926',
                      hintStyle: const TextStyle(fontSize: 14, color: Color(0xff6B6E82), fontWeight: FontWeight.w400),
                      fillColor: const Color(0xffF0F5FA),
                      filled: true,
                      contentPadding: const EdgeInsets.all(20),
                      border: OutlineInputBorder(borderSide: BorderSide.none, borderRadius: BorderRadius.circular(10))),
                ),
                const SizedBox(
                  height: 24,
                ),
                const Text(
                  'BIO',
                  style: TextStyle(fontSize: 14, fontWeight: FontWeight.w400, color: Color(0xff32343E)),
                ),
                const SizedBox(
                  height: 8,
                ),
                TextFormField(
                  decoration: InputDecoration(
                      hintText: 'I love fast food',
                      hintStyle: const TextStyle(fontSize: 14, color: Color(0xff6B6E82), fontWeight: FontWeight.w400),
                      fillColor: const Color(0xffF0F5FA),
                      filled: true,
                      contentPadding: const EdgeInsets.all(30),
                      border: OutlineInputBorder(borderSide: BorderSide.none, borderRadius: BorderRadius.circular(10))),
                ),
                const SizedBox(height: 32,),
                InkWell(onTap: (){
                  Navigator.push(context, MaterialPageRoute(builder: (context) => const PersonalInfoScreen(),));
                },
                  child: Container(
                    width: MediaQuery.of(context).size.width,
                    constraints: const BoxConstraints(minHeight: 62),
                    decoration: BoxDecoration(
                      borderRadius: BorderRadius.circular(20),
                      color:const Color(0xffFF7622)
                    ),child: const Center(child: Text('SAVE',style: TextStyle(fontSize: 16,fontWeight: FontWeight.w700,color: Colors.white),)),
                  ),
                )
              ],
            ),
          ),
        ),
      ),
    );
  }
}
