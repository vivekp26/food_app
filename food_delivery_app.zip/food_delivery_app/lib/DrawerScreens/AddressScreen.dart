import 'package:flutter/material.dart';
import 'package:food_delivery_app/DrawerScreens/AddAddress.dart';
import 'package:food_delivery_app/HomeScreens/HomePage.dart';

class AddressScreen extends StatefulWidget {
  const AddressScreen({super.key});

  @override
  State<AddressScreen> createState() => _AddressScreenState();
}

class _AddressScreenState extends State<AddressScreen> {
  @override
  Widget build(BuildContext context) {
    return Scaffold(
      body: SafeArea(child: SingleChildScrollView(
        child: Padding(
          padding: const EdgeInsets.all(24),
          child: Column(
            children: [
              // SizedBox(height: 24,),
              Row(
          children: [
          Container(
              constraints: const BoxConstraints(minHeight: 45,minWidth: 45),
              // height: 45,
          //     width: 45,
              decoration: const BoxDecoration(color: Color(0xffECF0F4), shape: BoxShape.circle),
              child: IconButton(onPressed: () {
                Navigator.push(context, MaterialPageRoute(builder: (context) => const HomePage(),));
              }, icon: const Icon(Icons.arrow_back_ios_outlined))),
            const SizedBox(
              width: 16,
            ),
            const Text(
              'My Address',
              style: TextStyle(color: Color(0xff181C2E), fontSize: 17, fontWeight: FontWeight.w400),
            ),
            ],
          ),
              const SizedBox(height: 24,),
              Container(
                width: MediaQuery.of(context).size.width,
                constraints:const BoxConstraints(minHeight: 101),
                decoration: BoxDecoration(
                  color: const Color(0xffF0F5FA),
                  borderRadius: BorderRadius.circular(20)
                ),child: Padding(
                  padding: const EdgeInsets.symmetric(horizontal: 15.0,vertical: 16),
                  child: Column(
                    children: [
                      Row(crossAxisAlignment: CrossAxisAlignment.start,
                        children: [
                          Container(
                            constraints: const BoxConstraints(minHeight: 48,minWidth: 48),
                            decoration: const BoxDecoration(
                              color: Colors.white,
                              shape: BoxShape.circle
                            ),child: const Icon(Icons.home_outlined,color: Color(0xff2790C3),),
                          ),
                          const SizedBox(width: 14,),
                          const Expanded(
                             child: Column(crossAxisAlignment: CrossAxisAlignment.start,
                               children: [
                                 Text('HOME',overflow: TextOverflow.ellipsis,style: TextStyle(color: Color(0xff32343E),fontWeight: FontWeight.w400,fontSize: 14),),
                                 SizedBox(height: 9,),
                                 Text('2464 Royal Ln. Mesa, New Jersey 45463',overflow: TextOverflow.ellipsis,maxLines: 2,style: TextStyle(color: Color(0xff32343E),fontWeight: FontWeight.w400,fontSize: 14),),
                               ],
                             ),
                           ),
                          IconButton(onPressed: (){}, icon: const Icon(Icons.edit_calendar_outlined,color: Color(0xffFB6D3A),)),
                          // SizedBox(width: 20,),
                          IconButton(onPressed: (){}, icon: const Icon(Icons.delete_outline,color: Color(0xffFB6D3A),)),
                        ],
                      ),
                    ],
                  ),
                ),
              ),
              const SizedBox(height: 20,),
              Container(
                width: MediaQuery.of(context).size.width,
                constraints: const BoxConstraints(minHeight: 101),
                decoration: BoxDecoration(
                    color: const Color(0xffF0F5FA),
                    borderRadius: BorderRadius.circular(20)
                ),child: Padding(
                padding: const EdgeInsets.symmetric(horizontal: 15.0,vertical: 16),
                child: Column(
                  children: [
                    Row(crossAxisAlignment: CrossAxisAlignment.start,
                      children: [
                        Container(
                          constraints: const BoxConstraints(minHeight: 48,minWidth: 48),
                          decoration: const BoxDecoration(
                              color: Colors.white,
                              shape: BoxShape.circle
                          ),child: const Icon(Icons.work_outline,color: Color(0xffA03BB1),),
                        ),
                        const SizedBox(width: 14,),
                        const Expanded(
                          child: Column(crossAxisAlignment: CrossAxisAlignment.start,
                            children: [
                              Text('WORK',overflow: TextOverflow.ellipsis,style: TextStyle(color: Color(0xff32343E),fontWeight: FontWeight.w400,fontSize: 14),),
                              SizedBox(height: 9,),
                              Text('3891 Ranchview Dr. Richardson, California 62639',overflow: TextOverflow.ellipsis,maxLines: 2,style: TextStyle(color: Color(0xff32343E),fontWeight: FontWeight.w400,fontSize: 14),),
                            ],
                          ),
                        ),
                        IconButton(onPressed: (){}, icon: const Icon(Icons.edit_calendar_outlined,color: Color(0xffFB6D3A),)),
                        // SizedBox(width: 20,),
                        IconButton(onPressed: (){}, icon: const Icon(Icons.delete_outline,color: Color(0xffFB6D3A),)),
                      ],
                    ),
                  ],
                ),
              ),
              ),
              const SizedBox(height: 379,),
              InkWell(onTap: (){
                Navigator.push(context, MaterialPageRoute(builder: (context) => AddAddressScreen()));
              },
                child: Container(
                  width: MediaQuery.of(context).size.width,
                  constraints: const BoxConstraints(minHeight: 62),
                  decoration: BoxDecoration(
                      borderRadius: BorderRadius.circular(20),
                      color: const Color(0xffFF7622)
                  ),child: const Center(child: Text('ADD NEW ADDRESS',style: TextStyle(fontSize: 16,fontWeight: FontWeight.w700,color: Colors.white),)),
                ),
              )
            ],
          ),
        ),
      )),
    );
  }
}
