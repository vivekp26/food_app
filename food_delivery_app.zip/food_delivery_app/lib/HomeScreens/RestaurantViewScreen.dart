import 'package:flutter/material.dart';
import 'package:food_delivery_app/HomeScreens/BurgerScreen.dart';
import 'package:food_delivery_app/HomeScreens/RestaurentView2.dart';

class RestaurentView extends StatefulWidget {
  const RestaurentView({super.key});

  @override
  State<RestaurentView> createState() => _RestaurentViewState();
}

class _RestaurentViewState extends State<RestaurentView> {
  List recentKeyList = ['Burger', 'Sandwich', 'Pizza', 'Sandwich'];
  int currentIndex = 0;
  List burgerName = ['Burger Ferguson', "Rockin' Burgers", 'Burger Ferguson', "Rockin' Burgers"];
  List burgerImage = ['assets/popular_burger1.jpg', 'assets/popular_burger2.jpg', 'assets/popular_burger3.jpg', 'assets/popular_burger4.jpg'];
  List burgerResto = [
    'Spicy restaurant',
    'Cafecafachino',
    'Spicy restaurant',
    'Cafecafachino',
  ];
  @override
  Widget build(BuildContext context) {
    return Scaffold(
      body: SafeArea(
        child: SingleChildScrollView(
          child: Column(
            crossAxisAlignment: CrossAxisAlignment.start,
            children: [const SizedBox(height: 24,),
              Padding(
                padding: const EdgeInsets.symmetric(horizontal: 24.0),
                child: Row(
                  mainAxisAlignment: MainAxisAlignment.spaceBetween,
                  children: [
                    Row(
                      children: [
                        Container(
                          constraints: const BoxConstraints(minWidth: 45,minHeight: 45),
                            decoration: const BoxDecoration(color: Color(0xffECF0F4), shape: BoxShape.circle),
                            child: IconButton(
                                onPressed: () {
                                  Navigator.push(
                                      context,
                                      MaterialPageRoute(
                                        builder: (context) => const BurgerScreen(),
                                      ));
                                },
                                icon: const Icon(Icons.arrow_back_ios_outlined))),
                        const SizedBox(
                          width: 16,
                        ),
                        const Text(
                          'Restaurant View',
                          style: TextStyle(color: Color(0xff181C2E), fontSize: 17, fontWeight: FontWeight.w700),
                        ),
                      ],
                    ),
                    Container(
                      constraints: const BoxConstraints(minWidth: 45,minHeight: 45),
                      decoration:const BoxDecoration(color: Color(0xffECF0F4), shape: BoxShape.circle),
                      child: IconButton(
                        icon: const Icon(
                          Icons.more_horiz_outlined,
                        ),
                        onPressed: () {},
                      ),
                    ),
                  ],
                ),
              ),
              const SizedBox(
                height: 24,
              ),
              Padding(
                padding: const EdgeInsets.symmetric(horizontal: 24.0),
                child: Container(
                  constraints: const BoxConstraints(minHeight: 150,),
                  // height: 150,
                  width: MediaQuery.of(context).size.width,
                  decoration: BoxDecoration(
                      borderRadius: BorderRadius.circular(20),
                      image: const DecorationImage(image: AssetImage('assets/open_resto_image.jpg'), fit: BoxFit.cover, filterQuality: FilterQuality.high)),
                ),
              ),
              const SizedBox(
                height: 24,
              ),
              Padding(
                padding: const EdgeInsets.symmetric(horizontal: 24.0),
                child: InkWell(
                    onTap: () {
                      Navigator.push(
                          context,
                          MaterialPageRoute(
                            builder: (context) => const RestaurentView2(),
                          ));
                    },
                    child: const Text(
                      'Spicy restaurant',
                      style: TextStyle(color: Color(0xff181C2E), fontSize: 20, fontWeight: FontWeight.w700),
                    )),
              ),
              const SizedBox(
                height: 4,
              ),
              const Padding(
                padding:  EdgeInsets.symmetric(horizontal: 24.0),
                child: Text(
                  'Maecenas sed diam eget risus varius blandit sit amet non magna. Integer posuere erat a ante venenatis dapibus posuere velit aliquet.',
                  style: TextStyle(color: Color(0xffA0A5BA), fontSize: 14, fontWeight: FontWeight.w400),
                ),
              ),
              const SizedBox(
                height: 21,
              ),
              const Padding(
                padding: EdgeInsets.symmetric(horizontal: 24.0),
                child: Row(
                  mainAxisAlignment: MainAxisAlignment.start,
                  children: [
                    Row(
                      children: [
                        Icon(
                          Icons.star_border_outlined,
                          color: Color(0xffFF7622),
                        ),
                        Text(
                          '4.7',
                          style: TextStyle(color: Color(0xff181C2E), fontSize: 16, fontWeight: FontWeight.w700),
                        )
                      ],
                    ),
                    SizedBox(
                      width: 36,
                    ),
                    Row(
                      children: [
                        Icon(
                          Icons.fire_truck_outlined,
                          color: Color(0xffFF7622),
                        ),
                        SizedBox(
                          width: 5,
                        ),
                        Text(
                          'Free',
                          style: TextStyle(color: Color(0xff181C2E), fontSize: 14, fontWeight: FontWeight.w400),
                        )
                      ],
                    ),
                    SizedBox(
                      width: 36,
                    ),
                    Row(
                      children: [
                        Icon(
                          Icons.watch_later_outlined,
                          color: Color(0xffFF7622),
                        ),
                        SizedBox(
                          width: 5,
                        ),
                        Text(
                          '20 min',
                          style: TextStyle(color: Color(0xff181C2E), fontSize: 14, fontWeight: FontWeight.w400),
                        ),
                      ],
                    ),
                  ],
                ),
              ),
              const SizedBox(
                height: 32,
              ),
              SizedBox(
                height: 50,
                child: ListView.separated(padding: const EdgeInsets.symmetric(horizontal: 24),
                  separatorBuilder: (context, index) {
                    return const SizedBox(
                      width: 10,
                    );
                  },
                  itemCount: recentKeyList.length,
                  shrinkWrap: true,
                  scrollDirection: Axis.horizontal,
                  itemBuilder: (context, index) {
                    return InkWell(
                      onTap: () {
                        setState(() {
                          currentIndex==index;
                        });
                      },
                      child: Container(
                        constraints: const BoxConstraints(minHeight: 46,minWidth: 120),
                        // height: 46,
                        // width: 120,
                        child: ElevatedButton(
                            style: ButtonStyle(
                                shadowColor: const MaterialStatePropertyAll(Colors.white),
                                backgroundColor: MaterialStatePropertyAll(currentIndex == index ? Color(0xffF58D1D) : Colors.white)),
                            onPressed: () {
                              // index==0?Navigator.push(context, MaterialPageRoute(builder: (context) => BurgerScreen(),)):null;
                            },
                            child: Text(
                              recentKeyList[index],
                              style: TextStyle(fontSize: 16, color:currentIndex==index? Colors.white:Colors.black, fontWeight: FontWeight.w400),
                            )),
                      ),
                    );
                  },
                ),
              ),
              const SizedBox(
                height: 32,
              ),
              const Padding(
                padding:  EdgeInsets.symmetric(horizontal: 24.0),
                child: Text(
                  'Burger (10)',
                  style: TextStyle(color: Color(0xff181C2E), fontSize: 20, fontWeight: FontWeight.w400),
                ),
              ),
              const SizedBox(
                height: 19,
              ),
              SizedBox(
                height: 400,
                child: GridView.builder(padding: const EdgeInsets.symmetric(horizontal: 24),
                  physics: const NeverScrollableScrollPhysics(),
                  itemCount: burgerImage.length,
                  scrollDirection: Axis.vertical,
                  gridDelegate: const SliverGridDelegateWithMaxCrossAxisExtent(
                    mainAxisSpacing: 21,
                    maxCrossAxisExtent: 200,
                    crossAxisSpacing: 21,
                  ),
                  itemBuilder: (context, index) {
                    return Container(
                      // constraints: BoxConstraints(minHeight: 180,minWidth: 153),
                      height: 180,
                      width: 153,
                      decoration: BoxDecoration(
                          // color: Colors.yellow,
                          borderRadius: BorderRadius.circular(20)),
                      child: SingleChildScrollView(
                        child: Column(
                          children: [
                            Container(
                              // constraints: BoxConstraints(minHeight: 84,minWidth: 130),
                              height: 84,
                              width: 130,
                              decoration: BoxDecoration(
                                  borderRadius: BorderRadius.circular(10),
                                  image:
                                      DecorationImage(image: AssetImage(burgerImage[index]), fit: BoxFit.cover, filterQuality: FilterQuality.high)),
                            ),
                            const SizedBox(
                              height: 6,
                            ),
                            Padding(
                              padding: const EdgeInsets.symmetric(horizontal: 20),
                              child: Column(
                                crossAxisAlignment: CrossAxisAlignment.start,
                                children: [
                                  InkWell(
                                      onTap: () {
                                        // index==0?Navigator.push(context, MaterialPageRoute(builder:(context) => BurgerBistroScreen(),)): null;
                                      },
                                      child: Text(
                                        burgerName[index],
                                        style: const TextStyle(fontSize: 15, fontWeight: FontWeight.w700, color: Color(0xff32343E)),
                                      )),
                                  const SizedBox(
                                    height: 5,
                                  ),
                                  Text(
                                    burgerResto[index],
                                    style: const TextStyle(fontSize: 13, fontWeight: FontWeight.w400, color: Color(0xff646982)),
                                  ),
                                  const SizedBox(
                                    height: 8,
                                  ),
                                  Row(
                                    mainAxisAlignment: MainAxisAlignment.spaceBetween,
                                    children: [
                                      const Text('\$40', style: TextStyle(fontSize: 16, color: Color(0xff32343E), fontWeight: FontWeight.w700)),
                                      InkWell(
                                        onTap: () {},
                                        child: Container(
                                            height: 30,
                                            width: 30,
                                            decoration: const BoxDecoration(shape: BoxShape.circle, color: Color(0xffF58D1D)),
                                            child: const Icon(Icons.add)),
                                      )
                                    ],
                                  )
                                ],
                              ),
                            ),
                          ],
                        ),
                      ),
                    );
                  },
                ),
              )
            ],
          ),
        ),
      ),
    );
  }
}
