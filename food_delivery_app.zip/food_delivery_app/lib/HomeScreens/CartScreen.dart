import 'package:flutter/material.dart';
import 'package:food_delivery_app/HomeScreens/HomePage.dart';
import 'package:food_delivery_app/HomeScreens/PopularFoodDetailScreen.dart';

class CartScreen extends StatefulWidget {
  const CartScreen({super.key});

  @override
  State<CartScreen> createState() => _CartScreenState();
}

class _CartScreenState extends State<CartScreen> {
  int _counter = 0;

  void incrementCounter() {
    setState(() {
      _counter++;
      print('counter:$_counter');
    });
  }

  void decrementCounter() {
    if (_counter > 0) {
      setState(() {
        _counter--;
        print('counter:$_counter');
      });
    }
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: Colors.black,
      body: SafeArea(
        child: SizedBox(
          height: MediaQuery.of(context).size.height,
          width: MediaQuery.of(context).size.width,
          child: SingleChildScrollView(
            child: Column(
              children: [
                Padding(
                  padding: const EdgeInsets.all(24),
                  child: Column(
                    crossAxisAlignment: CrossAxisAlignment.start,
                    children: [
                      Row(
                        mainAxisAlignment: MainAxisAlignment.spaceBetween,
                        children: [
                          Row(
                            children: [
                              Container(
                                  constraints: const BoxConstraints(minHeight: 45, minWidth: 45),
                                  // height: 45,
                                  // width: 45,
                                  decoration: BoxDecoration(color: Colors.black54, border: Border.all(), shape: BoxShape.circle),
                                  child: IconButton(
                                      onPressed: () {
                                        Navigator.push(
                                            context,
                                            MaterialPageRoute(
                                              builder: (context) => const PopularFoodDetailScreen(),
                                            ));
                                      },
                                      icon: const Icon(
                                        Icons.arrow_back_ios_outlined,
                                        color: Colors.white,
                                      ))),
                              const SizedBox(
                                width: 16,
                              ),
                              const Text(
                                'Cart',
                                style: TextStyle(color: Colors.white, fontSize: 17, fontWeight: FontWeight.w700),
                              ),
                            ],
                          ),
                          Row(
                            children: [
                              TextButton(
                                  onPressed: () {},
                                  child: const Text(
                                    'EDIT ITEMS',
                                    style: TextStyle(color: Color(0xffFF7622), fontWeight: FontWeight.w400, fontSize: 14),
                                  )),
                            ],
                          )
                        ],
                      ),
                      const SizedBox(
                        height: 24,
                      ),
                      Column(
                        crossAxisAlignment: CrossAxisAlignment.start,
                        children: [
                          Row(
                            children: [
                              Container(
                                constraints: const BoxConstraints(minHeight: 117, minWidth: 136),
                                // height: 117,
                                // width: 136,
                                decoration: BoxDecoration(
                                    borderRadius: BorderRadius.circular(20),
                                    image: const DecorationImage(
                                        image: AssetImage('assets/popular_food__-removebg-preview.png'),
                                        fit: BoxFit.cover,
                                        filterQuality: FilterQuality.high)),
                              ),
                              const SizedBox(
                                width: 20,
                              ),
                              Expanded(
                                child: Column(
                                  crossAxisAlignment: CrossAxisAlignment.start,
                                  children: [
                                    Row(
                                      children: [
                                        const Expanded(
                                            child: Text(
                                          'Pizza Calzone European',
                                          maxLines: 2,
                                          style: TextStyle(fontSize: 18, fontWeight: FontWeight.w400, color: Colors.white),
                                          overflow: TextOverflow.ellipsis,
                                        )),
                                        IconButton(
                                          style: const ButtonStyle(backgroundColor: MaterialStatePropertyAll(Colors.red)),
                                          onPressed: () {},
                                          icon: const Icon(Icons.cancel_outlined),
                                          color: Colors.white,
                                        ),
                                      ],
                                    ),
                                    const SizedBox(
                                      height: 10,
                                    ),
                                    const Text(
                                      '\$64',
                                      style: TextStyle(fontSize: 20, fontWeight: FontWeight.w700, color: Colors.white),
                                      overflow: TextOverflow.ellipsis,
                                    ),
                                    const SizedBox(
                                      height: 17,
                                    ),
                                    Row(
                                      mainAxisAlignment: MainAxisAlignment.spaceBetween,
                                      children: [
                                        const Text(
                                          "14'’",
                                          style: TextStyle(fontSize: 18, fontWeight: FontWeight.w400, color: Colors.white),
                                          overflow: TextOverflow.ellipsis,
                                        ),
                                        const Divider(),
                                        Row(
                                          // mainAxisAlignment: MainAxisAlignment.spaceAround,
                                          children: [
                                            InkWell(
                                              onTap: decrementCounter,
                                              child: Container(
                                                constraints: const BoxConstraints(minHeight: 24, minWidth: 24),
                                                // height: 24,
                                                // width: 24,
                                                decoration: const BoxDecoration(
                                                  color: Colors.grey,
                                                  shape: BoxShape.circle,
                                                ),
                                                child: const Icon(
                                                  Icons.remove,
                                                  color: Colors.white,
                                                ),
                                              ),
                                            ),
                                            const SizedBox(
                                              width: 19,
                                            ),
                                            Text(
                                              _counter.toString(),
                                              style: const TextStyle(fontSize: 16, fontWeight: FontWeight.w700, color: Colors.white),
                                            ),
                                            const SizedBox(
                                              width: 19,
                                            ),
                                            InkWell(
                                              onTap: incrementCounter,
                                              child: Container(
                                                constraints: const BoxConstraints(minHeight: 24, minWidth: 24),
                                                // height: 24,
                                                // width: 24,
                                                decoration: const BoxDecoration(
                                                  color: Colors.grey,
                                                  shape: BoxShape.circle,
                                                ),
                                                child: const Icon(
                                                  Icons.add,
                                                  color: Colors.white,
                                                ),
                                              ),
                                            )
                                          ],
                                        ),
                                      ],
                                    ),
                                  ],
                                ),
                              )
                            ],
                          ),
                        ],
                      ),
                      const SizedBox(
                        height: 32,
                      ),
                      Column(
                        crossAxisAlignment: CrossAxisAlignment.start,
                        children: [
                          Row(
                            children: [
                              Container(
                                constraints: const BoxConstraints(minHeight: 117, minWidth: 136),
                                // height: 117,
                                // width: 136,
                                decoration: BoxDecoration(
                                    borderRadius: BorderRadius.circular(20),
                                    image: const DecorationImage(
                                        image: AssetImage('assets/popular_food__-removebg-preview.png'),
                                        fit: BoxFit.cover,
                                        filterQuality: FilterQuality.high)),
                              ),
                              const SizedBox(
                                width: 20,
                              ),
                              Expanded(
                                child: Column(
                                  crossAxisAlignment: CrossAxisAlignment.start,
                                  children: [
                                    Row(
                                      children: [
                                        const Expanded(
                                            child: Text(
                                          'Pizza Calzone European',
                                          maxLines: 2,
                                          style: TextStyle(fontSize: 18, fontWeight: FontWeight.w400, color: Colors.white),
                                          overflow: TextOverflow.ellipsis,
                                        )),
                                        IconButton(
                                          style: const ButtonStyle(backgroundColor: MaterialStatePropertyAll(Colors.red)),
                                          onPressed: () {},
                                          icon: const Icon(Icons.cancel_outlined),
                                          color: Colors.white,
                                        ),
                                      ],
                                    ),
                                    const SizedBox(
                                      height: 10,
                                    ),
                                    const Text(
                                      '\$32',
                                      style: TextStyle(fontSize: 20, fontWeight: FontWeight.w700, color: Colors.white),
                                      overflow: TextOverflow.ellipsis,
                                    ),
                                    const SizedBox(
                                      height: 17,
                                    ),
                                    Row(
                                      mainAxisAlignment: MainAxisAlignment.spaceBetween,
                                      children: [
                                        const Text(
                                          "14'’",
                                          style: TextStyle(fontSize: 18, fontWeight: FontWeight.w400, color: Colors.white),
                                          overflow: TextOverflow.ellipsis,
                                        ),
                                        const Divider(),
                                        Row(
                                          // mainAxisAlignment: MainAxisAlignment.spaceAround,
                                          children: [
                                            InkWell(
                                              onTap: decrementCounter,
                                              child: Container(
                                                constraints: const BoxConstraints(minHeight: 24, minWidth: 24),
                                                // height: 24,
                                                // width: 24,
                                                decoration: const BoxDecoration(
                                                  color: Colors.grey,
                                                  shape: BoxShape.circle,
                                                ),
                                                child: const Icon(
                                                  Icons.remove,
                                                  color: Colors.white,
                                                ),
                                              ),
                                            ),
                                            const SizedBox(
                                              width: 19,
                                            ),
                                            Text(
                                              _counter.toString(),
                                              style: const TextStyle(fontSize: 16, fontWeight: FontWeight.w700, color: Colors.white),
                                            ),
                                            const SizedBox(
                                              width: 19,
                                            ),
                                            InkWell(
                                              onTap: incrementCounter,
                                              child: Container(
                                                constraints: const BoxConstraints(minHeight: 24, minWidth: 24),
                                                // height: 24,
                                                // width: 24,
                                                decoration: const BoxDecoration(
                                                  color: Colors.grey,
                                                  shape: BoxShape.circle,
                                                ),
                                                child: const Icon(
                                                  Icons.add,
                                                  color: Colors.white,
                                                ),
                                              ),
                                            )
                                          ],
                                        ),
                                      ],
                                    ),
                                  ],
                                ),
                              )
                            ],
                          ),
                        ],
                      ),
                    ],
                  ),
                ),
                const SizedBox(
                  height: 117,
                ),
                Container(
                  width: MediaQuery.of(context).size.width,
                  constraints: const BoxConstraints(minHeight: 310),
                  decoration: const BoxDecoration(
                      color: Colors.white, borderRadius: BorderRadius.only(topRight: Radius.circular(30), topLeft: Radius.circular(30))),
                  child: Padding(
                    padding: const EdgeInsets.symmetric(horizontal: 24, vertical: 24),
                    child: Column(
                      children: [
                        Row(
                          mainAxisAlignment: MainAxisAlignment.spaceBetween,
                          children: [
                            const Text(
                              'DELIVERY ADDRESS',
                              style: TextStyle(color: Color(0xffA0A5BA), fontWeight: FontWeight.w400, fontSize: 14),
                            ),
                            TextButton(
                                onPressed: () {},
                                child: const Text(
                                  'EDIT',
                                  style: TextStyle(color: Color(0xffFF7622), fontSize: 14, fontWeight: FontWeight.w400),
                                ))
                          ],
                        ),
                        const SizedBox(
                          height: 10,
                        ),
                        TextFormField(
                          style: const TextStyle(color: Color(0xffA0A5BA), fontSize: 14, fontWeight: FontWeight.w400),
                          decoration: InputDecoration(
                              hintText: '2118 Thornridge Cir. Syracuse',
                              hintStyle: const TextStyle(fontWeight: FontWeight.w400, fontSize: 14, color: Color(0XFF32343E)),
                              fillColor: const Color(0xffF0F5FA),
                              filled: true,
                              contentPadding: const EdgeInsets.all(25),
                              border: OutlineInputBorder(borderSide: BorderSide.none, borderRadius: BorderRadius.circular(10))),
                        ),
                        const SizedBox(
                          height: 30,
                        ),
                        Row(
                          mainAxisAlignment: MainAxisAlignment.spaceBetween,
                          children: [
                            const Row(
                              children: [
                                Text(
                                  'TOTAL: ',
                                  style: TextStyle(color: Color(0xffA0A5BA), fontSize: 14, fontWeight: FontWeight.w400),
                                ),
                                SizedBox(
                                  width: 12,
                                ),
                                Text('\$96', style: TextStyle(color: Color(0xff181C2E), fontSize: 30, fontWeight: FontWeight.w400))
                              ],
                            ),
                            Row(
                              children: [
                                TextButton(
                                    onPressed: () {},
                                    child: const Text(
                                      'Breakdown',
                                      style: TextStyle(color: Color(0xffFF7622), fontSize: 14, fontWeight: FontWeight.w400),
                                    )),
                                const Icon(
                                  Icons.arrow_forward_ios_outlined,
                                  size: 17,
                                )
                              ],
                            )
                          ],
                        ),
                        const SizedBox(
                          height: 32,
                        ),
                        Container(
                            constraints: const BoxConstraints(minHeight: 60),
                            width: MediaQuery.of(context).size.width,
                            child: ElevatedButton(
                                style: ButtonStyle(
                                    backgroundColor: const MaterialStatePropertyAll(Color(0xffFF7622)),
                                    shape: MaterialStatePropertyAll(RoundedRectangleBorder(borderRadius: BorderRadius.circular(15)))),
                                onPressed: () {
                                  Navigator.push(
                                      context,
                                      MaterialPageRoute(
                                        builder: (context) => const HomePage(),
                                      ));
                                },
                                child: const Text(
                                  'PLACE ORDER',
                                  style: TextStyle(color: Colors.white, fontSize: 14, fontWeight: FontWeight.w700),
                                )))
                      ],
                    ),
                  ),
                )
              ],
            ),
          ),
        ),
      ),
    );
  }
}
