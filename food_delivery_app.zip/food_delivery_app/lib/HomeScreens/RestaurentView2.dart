import 'package:flutter/material.dart';
import 'package:food_delivery_app/HomeScreens/RestaurantViewScreen.dart';

class RestaurentView2 extends StatefulWidget {
  const RestaurentView2({super.key});

  @override
  State<RestaurentView2> createState() => _RestaurentView2State();
}

class _RestaurentView2State extends State<RestaurentView2> {
  PageController _pageController = PageController();
  int currentIndex = 0;
  Widget indicator(int index) {
    return Padding(
      padding: const EdgeInsets.all(8.0),
      child: Container(
        height: 10,
        width: currentIndex == index ? 15 : 10,
        decoration: BoxDecoration(borderRadius: BorderRadius.circular(20), color: currentIndex == index ? Colors.white : Colors.grey),
      ),
    );
  }

  List restoImage = ['assets/restuarent_image.jpg', 'assets/open_resto_image.jpg', 'assets/restuarent_image.jpg', 'assets/open_resto_image.jpg'];
  List recentKeyList = ['Burger', 'Sandwich', 'Pizza', 'Sandwich'];
  int currIndex = 0;
  List burgerName = ['Burger Ferguson', "Rockin' Burgers", 'Burger Ferguson', "Rockin' Burgers"];
  List burgerImage = ['assets/popular_burger1.jpg', 'assets/popular_burger2.jpg', 'assets/popular_burger3.jpg', 'assets/popular_burger4.jpg'];
  List burgerResto = [
    'Spicy restaurant',
    'Cafecafachino',
    'Spicy restaurant',
    'Cafecafachino',
  ];
  List dialogOffers = ['Delivery', 'Pick Up', 'Offer', 'Online payment available'];
  List dialogDeliverTime = ['10-15 min', '20 min', '30 min'];
  @override
  void initState() {
    // TODO: implement initState
    Future.delayed(const Duration(seconds: 2), () {
      setState(() {
        _showDialog();
      });
    });
  }

  void _showDialog() {
    showDialog(
      useRootNavigator: true,
      context: context,
      useSafeArea: true,
      barrierDismissible: true,
      builder: (context) {
        return Dialog(
          backgroundColor: Colors.white,
          insetPadding: const EdgeInsets.all(10),
          child: SingleChildScrollView(
            child: Container(
              height: 700,
              width: 450,
              decoration: BoxDecoration(color: Colors.white, borderRadius: BorderRadius.circular(20)),
              child: Padding(
                padding: const EdgeInsets.all(20),
                child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
                  Row(
                    mainAxisAlignment: MainAxisAlignment.spaceBetween,
                    children: [
                      const Text('Filter your search',
                          style: TextStyle(
                            fontSize: 17,
                            fontWeight: FontWeight.w400,
                            color: Color(0xff181C2E),
                          )),
                      Container(
                        height: 45,
                        width: 45,
                        decoration: const BoxDecoration(color: Color(0xffECF0F4), shape: BoxShape.circle),
                        child: IconButton(
                            onPressed: () {
                              Navigator.of(context).pop();
                            },
                            icon: const Icon(Icons.cancel_outlined)),
                      ),
                    ],
                  ),
                  const SizedBox(
                    height: 30,
                  ),
                  const Text('OFFERS', style: TextStyle(fontSize: 17, fontWeight: FontWeight.w400, color: Color(0xff181C2E))),
                  const SizedBox(
                    height: 13,
                  ),
                  Row(
                    children: [
                      InkWell(
                        onTap: () {},
                        child: Container(
                          height: 46,
                          width: 100,
                          decoration: BoxDecoration(borderRadius: BorderRadius.circular(20), border: Border.all(color: const Color(0xffEDEDED), width: 2)),
                          child:const Center(
                              child: Text(
                            'Delivery',
                            style: TextStyle(color: Color(0xff464E57), fontWeight: FontWeight.w400, fontSize: 16),
                          )),
                        ),
                      ),
                      const SizedBox(
                        width: 16,
                      ),
                      InkWell(
                        onTap: () {},
                        child: Container(
                          height: 46,
                          width: 100,
                          decoration: BoxDecoration(borderRadius: BorderRadius.circular(20), border: Border.all(color: const Color(0xffEDEDED), width: 2)),
                          child: const Center(
                              child: Text(
                            'Pick Up',
                            style: TextStyle(color: Color(0xff464E57), fontWeight: FontWeight.w400, fontSize: 16),
                          )),
                        ),
                      ),
                      const SizedBox(
                        width: 16,
                      ),
                      InkWell(
                        onTap: () {},
                        child: Container(
                          height: 46,
                          width: 100,
                          decoration: BoxDecoration(borderRadius: BorderRadius.circular(20), border: Border.all(color: const Color(0xffEDEDED), width: 2)),
                          child: const Center(
                              child: Text(
                            'Offer',
                            style: TextStyle(color: Color(0xff464E57), fontWeight: FontWeight.w400, fontSize: 16),
                          )),
                        ),
                      ),
                    ],
                  ),
                  const SizedBox(
                    height: 9,
                  ),
                  InkWell(
                    onTap: () {},
                    child: Container(
                      height: 46,
                      width: 200,
                      decoration: BoxDecoration(borderRadius: BorderRadius.circular(20), border: Border.all(color: const Color(0xffEDEDED), width: 2)),
                      child: const Center(
                          child: Text(
                        'Online payment available',
                        style: TextStyle(color: Color(0xff464E57), fontWeight: FontWeight.w400, fontSize: 16),
                      )),
                    ),
                  ),
                  const SizedBox(
                    height: 32,
                  ),
                  const Text('DELIVER TIME',
                      style: TextStyle(
                        fontSize: 17,
                        fontWeight: FontWeight.w400,
                        color: Color(0xff181C2E),
                      )),
                  const SizedBox(
                    height: 12,
                  ),
                  SizedBox(
                    height: 50,
                    child: ListView.separated(
                      separatorBuilder: (context, index) {
                        return const SizedBox(
                          width: 10,
                        );
                      },
                      itemCount: dialogDeliverTime.length,
                      shrinkWrap: true,
                      scrollDirection: Axis.horizontal,
                      itemBuilder: (context, index) {
                        return InkWell(
                          onTap: () {
                            setState(() {
                              currentIndex==index;
                            });
                          },
                          child: Container(
                            height: 46,
                            width: 130,
                            child: ElevatedButton(
                                style: ButtonStyle(
                                    shadowColor: const MaterialStatePropertyAll(Colors.white),
                                    backgroundColor: MaterialStatePropertyAll(currentIndex == index ? const Color(0xffF58D1D) : Colors.white)),
                                onPressed: () {
                                  // index==0?Navigator.push(context, MaterialPageRoute(builder: (context) => BurgerScreen(),)):null;
                                },
                                child: Text(
                                  dialogDeliverTime[index],
                                  style: const TextStyle(fontSize: 16, color: Color(0xff181C2E), fontWeight: FontWeight.w400),
                                )),
                          ),
                        );
                      },
                    ),
                  ),
                  const SizedBox(
                    height: 32,
                  ),
                  const Text('PRICING',
                      style: TextStyle(
                        fontSize: 17,
                        fontWeight: FontWeight.w400,
                        color: Color(0xff181C2E),
                      )),
                  const SizedBox(
                    height: 12,
                  ),
                  Row(
                    mainAxisAlignment: MainAxisAlignment.start,
                    children: [
                      InkWell(
                        onTap: () {},
                        child: Container(
                          height: 48,
                          width: 48,
                          decoration: BoxDecoration(
                            shape: BoxShape.circle,
                            border: Border.all(color: const Color(0xffEDEDED), width: 2),
                          ),
                          child: const Center(child: Text('\$', style: TextStyle(color: Color(0xff464E57), fontSize: 20, fontWeight: FontWeight.w400))),
                        ),
                      ),
                      const SizedBox(
                        width: 10,
                      ),
                      InkWell(
                        onTap: () {},
                        child: Container(
                          height: 48,
                          width: 48,
                          decoration: BoxDecoration(
                            color: const Color(0xffF58D1D),
                            shape: BoxShape.circle,
                            border: Border.all(color: const Color(0xffEDEDED), width: 2),
                          ),
                          child: const Center(child: Text('\$\$', style: TextStyle(color: Colors.white, fontSize: 20, fontWeight: FontWeight.w400))),
                        ),
                      ),
                      const SizedBox(
                        width: 10,
                      ),
                      InkWell(
                        onTap: () {},
                        child: Container(
                          height: 48,
                          width: 48,
                          decoration: BoxDecoration(
                            shape: BoxShape.circle,
                            border: Border.all(color: const Color(0xffEDEDED), width: 2),
                            // image: DecorationImage(image: AssetImage('assets/dollar_three.png'),fit: BoxFit.fitWidth,filterQuality: FilterQuality.high)
                          ),
                          child: const Center(child: Text('\$\$\$', style: TextStyle(color: Color(0xff464E57), fontSize: 20, fontWeight: FontWeight.w400))),
                        ),
                      ),
                    ],
                  ),
                  const SizedBox(
                    height: 32,
                  ),
                  const Text('RATING',
                      style: TextStyle(
                        fontSize: 17,
                        fontWeight: FontWeight.w400,
                        color: Color(0xff181C2E),
                      )),
                  const SizedBox(
                    height: 12,
                  ),
                  Row(
                    children: [
                      Container(
                        height: 48,
                        width: 48,
                        decoration: BoxDecoration(shape: BoxShape.circle, border: Border.all(color: const Color(0xffEDEDED), width: 2)),
                        child: const Icon(
                          Icons.star_border_outlined,
                          color: Color(0xffFF7622),
                        ),
                      ),
                      const SizedBox(
                        width: 11,
                      ),
                      Container(
                        height: 48,
                        width: 48,
                        decoration: BoxDecoration(shape: BoxShape.circle, border: Border.all(color: const Color(0xffEDEDED), width: 2)),
                        child: const Icon(
                          Icons.star_border_outlined,
                          color: Color(0xffFF7622),
                        ),
                      ),
                      const SizedBox(
                        width: 11,
                      ),
                      Container(
                        height: 48,
                        width: 48,
                        decoration: BoxDecoration(shape: BoxShape.circle, border: Border.all(color: const Color(0xffEDEDED), width: 2)),
                        child: const Icon(
                          Icons.star_border_outlined,
                          color: Color(0xffFF7622),
                        ),
                      ),
                      const SizedBox(
                        width: 11,
                      ),
                      Container(
                          height: 48,
                          width: 48,
                          decoration: BoxDecoration(shape: BoxShape.circle, border: Border.all(color: const Color(0xffEDEDED), width: 2)),
                          child: const Icon(
                            Icons.star_border_outlined,
                            color: Color(0xffFF7622),
                          )),
                      const SizedBox(
                        width: 11,
                      ),
                      Container(
                        height: 48,
                        width: 48,
                        decoration: BoxDecoration(shape: BoxShape.circle, border: Border.all(color: const Color(0xffEDEDED), width: 2)),
                        child: const Icon(
                          Icons.star_border_outlined,
                        ),
                      ),
                    ],
                  ),
                  const SizedBox(
                    height: 31,
                  ),
                  Container(
                    height: 62,
                    width: MediaQuery.of(context).size.width,
                    child: ElevatedButton(
                        style: ButtonStyle(
                            backgroundColor: const MaterialStatePropertyAll(Color(0xffFF7622)),
                            shape: MaterialStatePropertyAll(RoundedRectangleBorder(borderRadius: BorderRadius.circular(20)))),
                        onPressed: () {
                          Navigator.of(context).pop();
                        },
                        child: const Text('FILTER',
                            style: TextStyle(
                              fontSize: 17,
                              fontWeight: FontWeight.w700,
                              color: Colors.white,
                            ))),
                  ),
                ]),
              ),
            ),
          ),
        );
      },
    );
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      body: SingleChildScrollView(
        child: Container(
          height: MediaQuery.of(context).size.height,
          width: MediaQuery.of(context).size.width,
          child: SingleChildScrollView(
            child: Column(
              children: [
                Column(
                  children: [
                    Container(
                      constraints: const BoxConstraints(maxHeight: 320),
                      // height: 320,
                      width: MediaQuery.of(context).size.width,
                      child: Expanded(
                        child: PageView.builder(
                          onPageChanged: (index) {
                            setState(() {
                              currentIndex = index;

                              // Navigator.push(context, MaterialPageRoute(builder: (context) => ));
                            });
                          },
                          controller: _pageController,
                          itemBuilder: (context, index) {
                            return Container(
                              constraints:  const BoxConstraints(minHeight: 320),
                              // height: 320,
                              width: MediaQuery.of(context).size.width,
                              decoration: BoxDecoration(
                                  // color: Color(0xffF58D1D),
                                  borderRadius: BorderRadius.circular(30),
                                  image: DecorationImage(image: AssetImage(restoImage[index]), filterQuality: FilterQuality.high, fit: BoxFit.cover)),
                              child: Align(
                                alignment: Alignment.topLeft,
                                child: Padding(
                                  padding: const EdgeInsets.only(left: 24, right: 24, top: 50),
                                  child: Column(
                                    mainAxisAlignment: MainAxisAlignment.spaceBetween,
                                    children: [
                                      Row(
                                        mainAxisAlignment: MainAxisAlignment.spaceBetween,
                                        children: [
                                          Container(
                                              constraints: const  BoxConstraints(minHeight: 45,minWidth: 45),
                                              // height: 45,
                                              // width: 45,
                                              decoration: const BoxDecoration(color: Color(0xffECF0F4), shape: BoxShape.circle),
                                              child: IconButton(
                                                  onPressed: () {
                                                    Navigator.push(
                                                        context,
                                                        MaterialPageRoute(
                                                          builder: (context) => const RestaurentView(),
                                                        ));
                                                  },
                                                  icon: const Icon(Icons.arrow_back_ios_outlined))),
                                          Container(
                                              constraints: const BoxConstraints(minHeight: 45,minWidth: 45),
                                              // height: 45,
                                              // width: 45,
                                              decoration:const BoxDecoration(color: Color(0xffECF0F4), shape: BoxShape.circle),
                                              child: IconButton(
                                                  onPressed: () {
                                                    // Navigator.push(context, MaterialPageRoute(builder: (context) => SearchBarScreen(),));
                                                  },
                                                  icon: const Icon(
                                                    Icons.favorite_border_outlined,
                                                  ))),
                                        ],
                                      ),
                                      // SizedBox(height: 20,),
                                      Row(
                                          crossAxisAlignment: CrossAxisAlignment.end,
                                          mainAxisAlignment: MainAxisAlignment.center,
                                          children: List.generate(restoImage.length, (index) {
                                            return indicator(index);
                                          })),
                                    ],
                                  ),
                                ),
                              ),
                            );
                          },
                          itemCount: restoImage.length,
                          scrollDirection: Axis.horizontal,
                        ),
                      ),
                    )
                  ],
                ),
                const SizedBox(
                  height: 15,
                ),
                Column(
                  crossAxisAlignment: CrossAxisAlignment.start,
                  children: [
                    const SizedBox(
                      height: 25,
                    ),
                    const  Padding(
                      padding:  EdgeInsets.symmetric(horizontal: 24.0),
                      child: Row(
                        mainAxisAlignment: MainAxisAlignment.start,
                        children: [
                          Row(
                            children: [
                              Icon(
                                Icons.star_border_outlined,
                                color: Color(0xffFF7622),
                              ),
                              Text(
                                '4.7',
                                style: TextStyle(color: Color(0xff181C2E), fontSize: 16, fontWeight: FontWeight.w700),
                              )
                            ],
                          ),
                          SizedBox(
                            width: 36,
                          ),
                          Row(
                            children: [
                              Icon(
                                Icons.fire_truck_outlined,
                                color: Color(0xffFF7622),
                              ),
                              SizedBox(
                                width: 5,
                              ),
                              Text(
                                'Free',
                                style: TextStyle(color: Color(0xff181C2E), fontSize: 14, fontWeight: FontWeight.w400),
                              )
                            ],
                          ),
                          SizedBox(
                            width: 36,
                          ),
                          Row(
                            children: [
                              Icon(
                                Icons.watch_later_outlined,
                                color: Color(0xffFF7622),
                              ),
                              SizedBox(
                                width: 5,
                              ),
                              Text(
                                '20 min',
                                style: TextStyle(color: Color(0xff181C2E), fontSize: 14, fontWeight: FontWeight.w400),
                              )
                            ],
                          ),
                        ],
                      ),
                    ),
                    const SizedBox(
                      height: 17,
                    ),
                    const Padding(
                      padding:  EdgeInsets.symmetric(horizontal: 24.0),
                      child: Text(
                        'Spicy restaurant',
                        style: TextStyle(color: Color(0xff181C2E), fontSize: 20, fontWeight: FontWeight.w400),
                      ),
                    ),
                    const SizedBox(
                      height: 20,
                    ),
                    const Padding(
                      padding:  EdgeInsets.symmetric(horizontal: 24.0),
                      child: Text(
                          'Maecenas sed diam eget risus varius blandit sit amet non magna. Integer posuere erat a ante venenatis dapibus posuere velit aliquet.',
                          style: TextStyle(
                            fontSize: 14,
                            fontWeight: FontWeight.w400,
                            color: Color(0xffA0A5BA),
                          )),
                    ),
                    const SizedBox(
                      height: 20,
                    ),
                    SizedBox(
                      height: 50,
                      child: ListView.separated(padding: const EdgeInsets.symmetric(horizontal: 24),
                        separatorBuilder: (context, index) {
                          return const SizedBox(
                            width: 10,
                          );
                        },
                        itemCount: recentKeyList.length,
                        shrinkWrap: true,
                        scrollDirection: Axis.horizontal,
                        itemBuilder: (context, index) {
                          return InkWell(
                            onTap: () {
                              setState(() {
                                currIndex==index;
                              });
                            },
                            child: Container(
                              constraints: const BoxConstraints(minHeight: 45,minWidth: 120),
                              // height: 46,
                              // width: 120,
                              child: ElevatedButton(
                                  style: ButtonStyle(
                                      shadowColor: const MaterialStatePropertyAll(Colors.white),
                                      backgroundColor: MaterialStatePropertyAll(currIndex == index ? const Color(0xffF58D1D) : Colors.white)),
                                  onPressed: () {
                                    // index==0?Navigator.push(context, MaterialPageRoute(builder: (context) => BurgerScreen(),)):null;
                                  },
                                  child: Text(
                                    recentKeyList[index],
                                    style: TextStyle(fontSize: 16, color:currIndex == index ? Colors.white : Colors.black , fontWeight: FontWeight.w400),
                                  )),
                            ),
                          );
                        },
                      ),
                    ),
                    const SizedBox(
                      height: 30,
                    ),
                    const Padding(
                      padding:  EdgeInsets.symmetric(horizontal: 24.0),
                      child: Text(
                        'Burger (10)',
                        style: TextStyle(color: Color(0xff181C2E), fontSize: 20, fontWeight: FontWeight.w400),
                      ),
                    ),
                    const SizedBox(
                      height: 16,
                    ),
                    SizedBox(
                      height: 450,
                      child: GridView.builder(padding: const EdgeInsets.symmetric(horizontal: 24),
                        physics: const NeverScrollableScrollPhysics(),
                        itemCount: burgerImage.length,
                        scrollDirection: Axis.vertical,
                        gridDelegate: const SliverGridDelegateWithMaxCrossAxisExtent(
                          mainAxisSpacing: 21,
                          maxCrossAxisExtent: 200,
                          crossAxisSpacing: 21,
                        ),
                        itemBuilder: (context, index) {
                          return Container(
                            height: 180,
                            width: 153,
                            decoration: BoxDecoration(
                                // color: Colors.yellow,
                                borderRadius: BorderRadius.circular(20)),
                            child: SingleChildScrollView(
                              child: Column(
                                children: [
                                  Container(
                                    height: 84,
                                    width: 130,
                                    decoration: BoxDecoration(
                                        borderRadius: BorderRadius.circular(10),
                                        image: DecorationImage(
                                            image: AssetImage(burgerImage[index]), fit: BoxFit.cover, filterQuality: FilterQuality.high)),
                                  ),
                                  const SizedBox(
                                    height: 6,
                                  ),
                                  Padding(
                                    padding: const EdgeInsets.symmetric(horizontal: 20),
                                    child: Column(
                                      crossAxisAlignment: CrossAxisAlignment.start,
                                      children: [
                                        InkWell(
                                            onTap: () {
                                              // index==0?Navigator.push(context, MaterialPageRoute(builder:(context) => BurgerBistroScreen(),)): null;
                                            },
                                            child: Text(
                                              burgerName[index],
                                              style: const TextStyle(fontSize: 15, fontWeight: FontWeight.w700, color: Color(0xff32343E)),
                                            )),
                                        const SizedBox(
                                          height: 5,
                                        ),
                                        Text(
                                          burgerResto[index],
                                          style: const TextStyle(fontSize: 13, fontWeight: FontWeight.w400, color: Color(0xff646982)),
                                        ),
                                        const SizedBox(
                                          height: 8,
                                        ),
                                        Row(
                                          mainAxisAlignment: MainAxisAlignment.spaceBetween,
                                          children: [
                                            const Text('\$40', style: TextStyle(fontSize: 16, color: Color(0xff32343E), fontWeight: FontWeight.w700)),
                                            InkWell(
                                              onTap: () {},
                                              child: Container(
                                                  constraints: const BoxConstraints(minHeight: 30,minWidth: 30),
                                                  // height: 30,
                                                  // width: 30,
                                                  decoration: const BoxDecoration(shape: BoxShape.circle, color: Color(0xffF58D1D)),
                                                  child: const Icon(Icons.add)),
                                            )
                                          ],
                                        )
                                      ],
                                    ),
                                  ),
                                ],
                              ),
                            ),
                          );
                        },
                      ),
                    )
                  ],
                ),
              ],
            ),
          ),
        ),
      ),
    );
  }
}
