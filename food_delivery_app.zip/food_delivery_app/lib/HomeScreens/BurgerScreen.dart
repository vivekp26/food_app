import 'package:flutter/material.dart';
import 'package:food_delivery_app/HomeScreens/BurgerBistroScreen.dart';
import 'package:food_delivery_app/HomeScreens/RestaurantViewScreen.dart';
import 'package:food_delivery_app/HomeScreens/SearchBarScreen.dart';

class BurgerScreen extends StatefulWidget {
  const BurgerScreen({super.key});

  @override
  State<BurgerScreen> createState() => _BurgerScreenState();
}

class _BurgerScreenState extends State<BurgerScreen> {
  List popularBurgerName = ['Burger Bistro', "Smokin' Burger", 'Buffalo Burgers', 'Bullseye Burgers'];
  List popularBurgerResto = [
    'Rose garden',
    'Cafenio Restaurant',
    'Kaji Firm Kitchen',
    'Kabab Restaurant',
  ];
  List popularBurgerImage = ['assets/popular_burger1.jpg', 'assets/popular_burger2.jpg', 'assets/popular_burger3.jpg', 'assets/popular_burger4.jpg'];
  List popularBurgerPrice = [
    '\$40',
    '\$60',
    '\$75',
    '\$94',
  ];
  List openRestoName = [
    'Tasty Treat Gallery',
    'Tasty Treat Gallery',
    'Tasty Treat Gallery',
    'Tasty Treat Gallery',
  ];
  List openRestoImage = [
    'assets/open_resto_image.jpg',
    'assets/open_resto_image.jpg',
    'assets/open_resto_image.jpg',
    'assets/open_resto_image.jpg',
  ];
  String selectedValue = 'Burger';

  @override
  Widget build(BuildContext context) {
    int itemCount = [
      popularBurgerName.length,
      popularBurgerResto.length,
      popularBurgerImage.length,
      popularBurgerPrice.length,
    ].reduce((value, element) => value < element ? value : element);
    return Scaffold(
      body: SafeArea(
          child: SingleChildScrollView(
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [const SizedBox(height: 24,),
                Padding(
                  padding: const EdgeInsets.symmetric(horizontal: 24.0),
                  child: Row(
                    mainAxisAlignment: MainAxisAlignment.spaceBetween,
                    children: [
                      Row(
                        children: [
                          Container(
                            constraints: const BoxConstraints(minHeight: 45,minWidth: 45),
                              decoration: const BoxDecoration(color: Color(0xffECF0F4), shape: BoxShape.circle),
                              child: IconButton(
                                  onPressed: () {
                                    Navigator.push(
                                        context,
                                        MaterialPageRoute(
                                          builder: (context) => const SearchBarScreen(),
                                        ));
                                  },
                                  icon: const Icon(Icons.arrow_back_ios_outlined))),
                          const SizedBox(
                            width: 16,
                          ),
                          Container(
                            height: 48,
                            width: 120,
                            decoration: BoxDecoration(border: Border.all(), borderRadius: BorderRadius.circular(30)),
                            child: Center(
                              child: DropdownButton(
                                  padding: const EdgeInsets.symmetric(horizontal: 5),
                                  iconEnabledColor: const Color(0xffF58D1D),
                                  value: selectedValue,
                                  underline: Container(),
                                  borderRadius: BorderRadius.circular(10),
                                  autofocus: true,
                                  focusColor: const Color(0xffF58D1D),
                                  style: const TextStyle(color: Color(0xff181C2E), fontSize: 17, fontWeight: FontWeight.w700),
                                  items: <String>['Burger', 'Pizza', 'Sandwich', 'Hotdog'].map<DropdownMenuItem<String>>((String value) {
                                    return DropdownMenuItem<String>(
                                        value: value,
                                        child: Text(
                                          value,
                                          style: const TextStyle(color: Color(0xff181C2E), fontSize: 17, fontWeight: FontWeight.w700),
                                        ));
                                  }).toList(),
                                  onChanged: (String? newValue) {
                                    setState(() {
                                      selectedValue = newValue!;
                                      print('value: $newValue');
                                    });
                                  }),
                            ),
                          ),
                        ],
                      ),
                      Container(
                        constraints: const BoxConstraints(minHeight: 45,minWidth: 45),
                        decoration: const BoxDecoration(color: Color(0xff181C2E), shape: BoxShape.circle),
                        child: IconButton(
                          icon: const Icon(
                            Icons.card_travel_outlined,
                            color: Colors.white,
                          ),
                          onPressed: () {},
                        ),
                      ),
                    ],
                  ),
                ),
                const SizedBox(
                  height: 24,
                ),
                const Padding(
                  padding: const EdgeInsets.symmetric(horizontal: 24.0),
                  child: Text(
                    'Popular Burgers',
                    style: TextStyle(fontSize: 20, color: Color(0xff32343E), fontWeight: FontWeight.w400),
                  ),
                ),
                const SizedBox(
                  height: 24,
                ),
                SizedBox(
                  height: 400,
                  child: GridView.builder(padding: const EdgeInsets.symmetric(horizontal: 24),
                    physics: const NeverScrollableScrollPhysics(),
                    itemCount: itemCount,
                    scrollDirection: Axis.vertical,
                    gridDelegate: const SliverGridDelegateWithMaxCrossAxisExtent(
                      mainAxisSpacing: 21,
                      maxCrossAxisExtent: 200,
                      crossAxisSpacing: 21,
                    ),
                    itemBuilder: (context, index) {
                      return Container(
                        // constraints: BoxConstraints(minHeight: 180,minWidth: 153),
                        height: 180,
                        width: 153,
                        decoration: BoxDecoration(
                            // color: Colors.yellow,
                            borderRadius: BorderRadius.circular(20)),
                        child: SingleChildScrollView(
                          child: Column(
                            children: [
                              Container(
                                // constraints: BoxConstraints(minWidth: 130,minHeight: 84),
                                height: 84,
                                width: 130,
                                decoration: BoxDecoration(
                                    borderRadius: BorderRadius.circular(10),
                                    image: DecorationImage(
                                        image: AssetImage(popularBurgerImage[index]), fit: BoxFit.cover, filterQuality: FilterQuality.high)),
                              ),
                              const SizedBox(
                                height: 6,
                              ),
                              Padding(
                                padding: const EdgeInsets.symmetric(horizontal: 20),
                                child: Column(
                                  crossAxisAlignment: CrossAxisAlignment.start,
                                  children: [
                                    InkWell(
                                        onTap: () {
                                          index == 0
                                              ? Navigator.push(
                                                  context,
                                                  MaterialPageRoute(
                                                    builder: (context) => const BurgerBistroScreen(),
                                                  ))
                                              : null;
                                        },
                                        child: Text(
                                          popularBurgerName[index],
                                          style: const TextStyle(fontSize: 15, fontWeight: FontWeight.w700, color: Color(0xff32343E)),
                                        )),
                                    const SizedBox(
                                      height: 5,
                                    ),
                                    Text(
                                      popularBurgerResto[index],
                                      style: const TextStyle(fontSize: 13, fontWeight: FontWeight.w400, color: Color(0xff646982)),
                                    ),
                                    const SizedBox(
                                      height: 8,
                                    ),
                                    Row(
                                      mainAxisAlignment: MainAxisAlignment.spaceBetween,
                                      children: [
                                        Text(popularBurgerPrice[index],
                                            style: const TextStyle(fontSize: 16, color: Color(0xff32343E), fontWeight: FontWeight.w700)),
                                        InkWell(
                                          onTap: () {},
                                          child: Container(
                                            constraints: const BoxConstraints(minHeight: 30,minWidth: 30),
                                              // height: 30,
                                              // width: 30,
                                              decoration: const BoxDecoration(shape: BoxShape.circle, color: Color(0xffF58D1D)),
                                              child: const Icon(Icons.add)),
                                        )
                                      ],
                                    )
                                  ],
                                ),
                              ),
                            ],
                          ),
                        ),
                      );
                    },
                  ),
                ),
                // SizedBox(height: 10,),
                const Padding(
                  padding: EdgeInsets.symmetric(horizontal: 24.0),
                  child: Text(
                    'Open Resturants',
                    style: TextStyle(color: Color(0xff32343E), fontSize: 20, fontWeight: FontWeight.w400),
                  ),
                ),
                const SizedBox(
                  height: 20,
                ),
                ListView.separated(padding: const EdgeInsets.symmetric(horizontal: 24),
                    physics: const NeverScrollableScrollPhysics(),
                    shrinkWrap: true,
                    scrollDirection: Axis.vertical,
                    itemBuilder: (context, index) {
                      return SizedBox(
                        // color: Colors.black,
                        // height: MediaQuery.of(context).size.height,
                        width: MediaQuery.of(context).size.width,
                        // color: Colors.red,
                        child: Column(
                          crossAxisAlignment: CrossAxisAlignment.start,
                          children: [
                            Container(
                              constraints: const BoxConstraints(minHeight: 140),
                                // height: 140,
                                width: MediaQuery.of(context).size.width,
                                decoration: BoxDecoration(
                                    borderRadius: BorderRadius.circular(10),
                                    image: DecorationImage(image: AssetImage(openRestoImage[index]), fit: BoxFit.cover))),
                            const SizedBox(
                              height: 14,
                            ),
                            InkWell(
                                onTap: () {
                                  index == 0
                                      ? Navigator.push(
                                          context,
                                          MaterialPageRoute(
                                            builder: (context) => const RestaurentView(),
                                          ))
                                      : null;
                                },
                                child: Text(
                                  openRestoName[index],
                                  style: const TextStyle(color: Color(0xff181C2E), fontSize: 20, fontWeight: FontWeight.w400),
                                )),
                            const SizedBox(
                              height: 8,
                            ),
                            const Row(
                              children: [
                                Row(
                                  children: [
                                    Icon(
                                      Icons.star_border_outlined,
                                      color: Color(0xffFF7622),
                                    ),
                                    Text(
                                      '4.7',
                                      style: TextStyle(color: Color(0xff181C2E), fontSize: 16, fontWeight: FontWeight.w700),
                                    )
                                  ],
                                ),
                                SizedBox(
                                  width: 24,
                                ),
                                Row(
                                  children: [
                                    Icon(
                                      Icons.fire_truck_outlined,
                                      color: Color(0xffFF7622),
                                    ),
                                    SizedBox(
                                      width: 5,
                                    ),
                                    Text(
                                      'Free',
                                      style: TextStyle(color: Color(0xff181C2E), fontSize: 14, fontWeight: FontWeight.w400),
                                    )
                                  ],
                                ),
                                SizedBox(
                                  width: 24,
                                ),
                                Row(
                                  children: [
                                    Icon(
                                      Icons.watch_later_outlined,
                                      color: Color(0xffFF7622),
                                    ),
                                    SizedBox(
                                      width: 5,
                                    ),
                                    Text(
                                      '20 min',
                                      style: TextStyle(color: Color(0xff181C2E), fontSize: 14, fontWeight: FontWeight.w400),
                                    )
                                  ],
                                ),
                              ],
                            )
                          ],
                        ),
                      );
                    },
                    separatorBuilder: (context, index) {
                      return const SizedBox(
                        height: 20,
                      );
                    },
                    itemCount: openRestoImage.length),
              ],
            ),
          )),
    );
  }
}
