import 'package:flutter/material.dart';
import 'package:food_delivery_app/HomeScreens/BurgerScreen.dart';
import 'package:food_delivery_app/HomeScreens/HomePage.dart';
import 'package:food_delivery_app/HomeScreens/PopularFoodDetailScreen.dart';

class SearchBarScreen extends StatefulWidget {
  const SearchBarScreen({super.key});

  @override
  State<SearchBarScreen> createState() => _SearchBarScreenState();
}

class _SearchBarScreenState extends State<SearchBarScreen> {
  List recentKeyList = ['Burger', 'Sandwich', 'Pizza', 'Sandwich'];
  List suggestedRestoImage = [
    'assets/resto1.jpg',
    'assets/resto2.jpg',
    'assets/resto3.jpg',
  ];
  List suggestedRestoNames = [
    'Pansi Restaurant',
    'American Spicy Burger Shop',
    'Cafenio Coffee Club',
  ];
  List restoReview = ['4.7', '4.3', '4.0'];
  List popularFood = ['european Pizza', 'Buffalo Pizza.', 'european Pizza', 'Buffalo Pizza.'];
  List popularRestoNames = ['Uttora Coffe House', 'Cafenio Coffee Club', 'Uttora Coffe House', 'Cafenio Coffee Club'];
  List popularFoodImage = [
    'assets/popular_food_!.jpg',
    'assets/popular_food_2.jpg',
    'assets/popular_food_!.jpg',
    'assets/popular_food_2.jpg',
  ];
  @override
  Widget build(BuildContext context) {
    return Scaffold(
      body: SafeArea(
        child: SingleChildScrollView(
          child: Column(
            crossAxisAlignment: CrossAxisAlignment.start,
            children: [const SizedBox(height: 24,),
              Padding(
                padding: const EdgeInsets.symmetric(horizontal: 24.0,),
                child: Row(
                  mainAxisAlignment: MainAxisAlignment.spaceBetween,
                  children: [
                    Row(
                      children: [
                        Container(
                          constraints: const BoxConstraints(minHeight: 45,minWidth: 45),
                            decoration: const BoxDecoration(color: Color(0xffECF0F4), shape: BoxShape.circle),
                            child: IconButton(
                                onPressed: () {
                                  Navigator.push(
                                      context,
                                      MaterialPageRoute(
                                        builder: (context) => const HomePage(),
                                      ));
                                },
                                icon: const Icon(Icons.arrow_back_ios_outlined))),
                        const SizedBox(
                          width: 16,
                        ),
                        const Text(
                          'Search',
                          style: TextStyle(color: Color(0xff181C2E), fontSize: 17, fontWeight: FontWeight.w700),
                        ),
                      ],
                    ),
                    Container(
                      constraints: const BoxConstraints(minWidth: 45,minHeight: 45),
                      decoration: const BoxDecoration(color: Color(0xff181C2E), shape: BoxShape.circle),
                      child: IconButton(
                        icon: const Icon(
                          Icons.card_travel_outlined,
                          color: Colors.white,
                        ),
                        onPressed: () {},
                      ),
                    ),
                  ],
                ),
              ),
              const SizedBox(
                height: 24,
              ),
              Padding(
                padding: const EdgeInsets.symmetric(horizontal: 24.0),
                child: TextFormField(
                  decoration: InputDecoration(
                    contentPadding: const EdgeInsets.all(25),
                    filled: true,
                    fillColor: const Color(0xffF6F6F6),
                    hintStyle: const TextStyle(color: Color(0xff676767), fontWeight: FontWeight.w400, fontSize: 15),
                    hintText: 'Pizza',
                    suffixIcon: IconButton(
                      style: const ButtonStyle(iconSize: MaterialStatePropertyAll(30)),
                      onPressed: () {},
                      icon: const Icon(Icons.cancel_outlined),
                      color: const Color(0xffA0A5BA),
                    ),
                    prefixIcon: const Icon(
                      Icons.search,
                      color: Color(0xffA0A5BA),
                      size: 30,
                    ),
                    border: OutlineInputBorder(
                      borderSide: BorderSide.none,
                      borderRadius: BorderRadius.circular(12),
                    ),
                  ),
                ),
              ),
              const SizedBox(
                height: 24,
              ),
              const Padding(
                padding: EdgeInsets.symmetric(horizontal: 24.0),
                child: Text(
                  'Recent Keywords',
                  style: TextStyle(fontSize: 20, color: Color(0xff32343E), fontWeight: FontWeight.w400),
                ),
              ),
              SizedBox(
                height: 12,
              ),
              SizedBox(
                height: 50,
                child: ListView.separated(padding: const EdgeInsets.symmetric(horizontal: 24),
                  separatorBuilder: (context, index) {
                    return const SizedBox(
                      width: 10,
                    );
                  },
                  itemCount: recentKeyList.length,
                  shrinkWrap: true,
                  scrollDirection: Axis.horizontal,
                  itemBuilder: (context, index) {
                    return Container(
                      constraints:const BoxConstraints(minWidth: 120,minHeight: 46),
                      // height: 46,
                      // width: 120,
                      child: ElevatedButton(
                          style: const ButtonStyle(
                              shadowColor: MaterialStatePropertyAll(Color(0xffEDEDED)),
                              backgroundColor: MaterialStatePropertyAll(
                                Colors.white,
                              )),
                          onPressed: () {
                            index == 0
                                ? Navigator.push(
                                    context,
                                    MaterialPageRoute(
                                      builder: (context) => const BurgerScreen(),
                                    ))
                                : null;
                          },
                          child: Text(
                            recentKeyList[index],
                            style: const TextStyle(fontSize: 16, color: Color(0xff181C2E), fontWeight: FontWeight.w400),
                          )),
                    );
                  },
                ),
              ),
              const SizedBox(
                height: 32,
              ),
              const Padding(
                padding: EdgeInsets.symmetric(horizontal: 24.0),
                child: Text(
                  'Suggested Restaurants',
                  style: TextStyle(fontSize: 20, color: Color(0XFF32343E), fontWeight: FontWeight.w400),
                ),
              ),
              const SizedBox(
                height: 20,
              ),
              ListView.separated(padding: const EdgeInsets.symmetric(horizontal: 24),
                  scrollDirection: Axis.vertical,
                  shrinkWrap: true,
                  itemBuilder: (context, index) {
                    return Container(
                      // height: 100,
                      width: MediaQuery.of(context).size.width,
                      margin: const EdgeInsets.all(10),
                      // padding: EdgeInsets.all(10),
                      decoration: BoxDecoration(
                        // color: Colors.yellow,
                        borderRadius: BorderRadius.circular(10),
                        // border: Border.all(color: Colors.black)
                      ),
                      child: Row(
                        children: [
                          Container(
                            constraints: const BoxConstraints(minHeight: 50,minWidth: 60),
                            // height: 50,
                            // width: 60,
                            decoration: BoxDecoration(
                                borderRadius: BorderRadius.circular(10),
                                image: DecorationImage(
                                    image: AssetImage(suggestedRestoImage[index]), fit: BoxFit.cover, filterQuality: FilterQuality.high)),
                          ),
                          const SizedBox(
                            width: 10,
                          ),
                          Column(
                            crossAxisAlignment: CrossAxisAlignment.start,
                            children: [
                              Text(
                                suggestedRestoNames[index],
                                style: const TextStyle(color: Color(0xff32343E), fontSize: 18, fontWeight: FontWeight.w400),
                              ),
                              Row(
                                children: [
                                  const Icon(
                                    Icons.star_border_outlined,
                                    color: Color(0xffFF7622),
                                  ),
                                  Text(
                                    restoReview[index],
                                    style: const TextStyle(color: Color(0xff181C2E), fontSize: 16, fontWeight: FontWeight.w400),
                                  )
                                ],
                              )
                            ],
                          ),
                        ],
                      ),
                    );
                  },
                  separatorBuilder: (context, index) {
                    return Divider();
                  },
                  itemCount: suggestedRestoNames.length),
              const SizedBox(
                height: 32,
              ),
              const Padding(
                padding:  EdgeInsets.symmetric(horizontal: 24.0),
                child: Text(
                  'Popular Fast food',
                  style: TextStyle(color: Color(0xff181C2E), fontSize: 20, fontWeight: FontWeight.w400),
                ),
              ),
              const SizedBox(
                height: 27,
              ),
              SizedBox(
                height: 200,
                child: ListView.separated(padding: const EdgeInsets.symmetric(horizontal: 24),
                    scrollDirection: Axis.horizontal,
                    shrinkWrap: true,
                    itemBuilder: (context, index) {
                      return Container(
                        // width: MediaQuery.of(context).size.width,
                        // color: Colors.yellow,
                        child: Column(
                          children: [
                            Container(
                              constraints: const BoxConstraints(minWidth: 150,minHeight: 150),
                              // height: 150,
                              // width: 150,
                              decoration: BoxDecoration(borderRadius: BorderRadius.circular(20)),
                              child: Column(
                                children: [
                                  InkWell(
                                    onTap: () {
                                      Navigator.push(
                                          context,
                                          MaterialPageRoute(
                                            builder: (context) => const PopularFoodDetailScreen(),
                                          ));
                                    },
                                    child: Container(
                                      constraints: const BoxConstraints(minHeight: 84,minWidth: 122),
                                      // height: 84,
                                      // width: 122,
                                      decoration: BoxDecoration(
                                          borderRadius: BorderRadius.circular(10),
                                          image: DecorationImage(image: AssetImage(popularFoodImage[index]))),
                                    ),
                                  ),
                                  Text(
                                    popularFood[index],
                                    style: const TextStyle(color: Color(0xff32343E), fontWeight: FontWeight.w700, fontSize: 15),
                                  ),
                                  Text(
                                    popularRestoNames[index],
                                    style: const TextStyle(color: Color(0xff646982), fontWeight: FontWeight.w700, fontSize: 13),
                                  ),
                                ],
                              ),
                            )
                          ],
                        ),
                      );
                    },
                    separatorBuilder: (context, index) {
                      return const SizedBox(
                        width: 20,
                      );
                    },
                    itemCount: popularFood.length),
              )
            ],
          ),
        ),
      ),
    );
  }
}
