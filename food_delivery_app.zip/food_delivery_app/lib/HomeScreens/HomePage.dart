  import 'package:flutter/material.dart';
import 'package:food_delivery_app/DrawerScreens/AddressScreen.dart';
import 'package:food_delivery_app/DrawerScreens/PersonalInfoScreen.dart';
  import 'package:food_delivery_app/HomeScreens/SearchBarScreen.dart';

  class HomePage extends StatefulWidget {
    const HomePage({super.key});

    @override
    State<HomePage> createState() => _HomePageState();
  }

  class _HomePageState extends State<HomePage> {
    final GlobalKey<ScaffoldState> _scaffoldKey = GlobalKey<ScaffoldState>();
    List categoryImage = ['assets/pizzaa_image.jpg', 'assets/burger_image.jpg', 'assets/hotDog_image.jpg'];
    List categoryName = ['Pizza', 'Burger', 'Hot Dog'];
    List categoryPrice = [
      '\$70',
      '\$50',
      '\$60',
    ];
    List restoImage = [
      'assets/restuarent_image.jpg',
      'assets/restuarent_image.jpg',
      'assets/restuarent_image.jpg',
    ];
    List restoNames = [
      'Rose Garden Restaurant',
      'Rose Garden Restaurant',
      'Rose Garden Restaurant',
    ];
    List restoMenuItems = [
      'Burger - Chiken - Riche - Wings ',
      'Burger - Chiken - Riche - Wings ',
      'Burger - Chiken - Riche - Wings ',
    ];
    @override
    void initState() {
      // TODO: implement initState
      Future.delayed(const Duration(seconds: 2), () {
        _showDialog();
      });
    }

    void _showDialog() {
      showDialog(
        context: context,
        barrierDismissible: true, // Prevent dismissing by tapping outside the dialog
        builder: (BuildContext context) {
          return  AlertDialog(elevation: 0,contentPadding: const EdgeInsets.all(5),
            backgroundColor: Colors.transparent,
            content: Container(
              width: MediaQuery.of(context).size.width,
              constraints: const BoxConstraints(maxHeight: 430,),
              decoration: BoxDecoration(
                  borderRadius: BorderRadius.circular(30), // Adjust the border radius as needed
                  gradient: const LinearGradient(
                     begin: Alignment.topLeft,
                    end: Alignment.bottomRight,
                    colors: [
                      Color(0xffFFEB34),
                      Color(0xffE76F00),
                    ],
                  )),
              child: Padding(
                padding: const EdgeInsets.symmetric(vertical: 82,horizontal: 30),
                child: SingleChildScrollView(
                  child: Column(
                    children: [
                      const Text(overflow: TextOverflow.ellipsis,
                        'Hurry offers!',
                        style: TextStyle(color: Colors.white,fontSize: 40, fontWeight: FontWeight.w800),
                      ),
                      const SizedBox(height: 35,),
                      const Column(crossAxisAlignment: CrossAxisAlignment.center,
                        children: [
                          Text('#1243CD2',overflow: TextOverflow.ellipsis,maxLines: 3, style: TextStyle(color: Colors.white,fontSize: 30, fontWeight: FontWeight.w700)),
                          SizedBox(height: 20,),
                          Text('Use the cupon get 25% discount',maxLines: 2,overflow: TextOverflow.ellipsis, style: TextStyle(color: Colors.white,fontSize: 16, fontWeight: FontWeight.w700)),
                        ],
                      ),
                      const SizedBox(height: 17,),
                      InkWell(onTap: (){
                        Navigator.of(context).pop();
                      },
                        child: Container(
                          constraints: const BoxConstraints(minHeight: 62),
                          width: MediaQuery.of(context).size.width,
                          decoration: BoxDecoration(
                            border: Border.all(color: Colors.white),
                            borderRadius: BorderRadius.circular(10),
                          ),
                          child: const Center(
                            child:  Text(
                              'GOT IT',
                              style: TextStyle(color: Colors.white, fontWeight: FontWeight.w700, fontSize: 18),
                            ),
                          ),
                        ),
                      ),
                    ],
                  ),
                ),
              ),
            ),
          );
        },
      );
    }

    @override
    Widget build(BuildContext context) {
      return Scaffold(
        key: _scaffoldKey,
        drawer: Drawer(
          key: GlobalKey(),
          shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(30)),
          width: 350,
          shadowColor: Colors.white,
          surfaceTintColor: Colors.white,
          backgroundColor: Colors.white,
          child: SafeArea(
            child: Padding(
              padding: const EdgeInsets.symmetric(horizontal: 24),
              child: SingleChildScrollView(
                child: Column(
                  children: [const SizedBox(height: 24,),
                    Row(
                      mainAxisAlignment: MainAxisAlignment.spaceBetween,
                      children: [
                        Row(
                          children: [
                            Container(
                                constraints: const BoxConstraints(minHeight: 45,minWidth: 45),
                                // height: 45,
                                // width: 45,
                                decoration: const BoxDecoration(color: Color(0xffECF0F4), shape: BoxShape.circle),
                                child: IconButton(
                                    onPressed: () {
                                      Navigator.push(
                                          context,
                                          MaterialPageRoute(
                                            builder: (context) => const HomePage(),
                                          ));
                                    },
                                    icon: const Icon(Icons.arrow_back_ios_outlined))),
                            const SizedBox(
                              width: 16,
                            ),
                            const Text(
                              'Profile',
                              style: TextStyle(color: Color(0xff181C2E), fontSize: 17, fontWeight: FontWeight.w400),
                            ),
                          ],
                        ),
                        Container(
                          constraints: const BoxConstraints(minHeight: 45,minWidth: 45),
                          // height: 49,
                          // width: 45,
                          decoration: const BoxDecoration(color: Color(0xffECF0F4), shape: BoxShape.circle),
                          child: IconButton(
                            icon: const Icon(
                              Icons.more_horiz_outlined,
                              // color: Colors.white,
                            ),
                            onPressed: () {},
                          ),
                        ),
                      ],
                    ),
                    const SizedBox(
                      height: 24,
                    ),
                    Row(
                      children: [
                        Container(
                          constraints: const BoxConstraints(minHeight: 100, minWidth: 100),
                          decoration: const BoxDecoration(shape: BoxShape.circle, color: Colors.orangeAccent),
                          child: const Icon(Icons.person),
                        ),
                        const Padding(
                          padding: EdgeInsets.symmetric(horizontal: 15),
                          child: Column(
                            children: [
                              Text(
                                'Vishal Khadok',
                                overflow: TextOverflow.ellipsis,
                                style: TextStyle(fontSize: 20, color: Color(0xff32343E), fontWeight: FontWeight.w700),
                              ),
                              SizedBox(
                                height: 8,
                              ),
                              Text(
                                'I love fast food',
                                overflow: TextOverflow.ellipsis,
                                style: TextStyle(fontSize: 14, color: Color(0xffA0A5BA), fontWeight: FontWeight.w400),
                              ),
                            ],
                          ),
                        )
                      ],
                    ),
                    const SizedBox(height: 32),
                    Container(
                      width: MediaQuery.of(context).size.width,
                      constraints: const BoxConstraints(minHeight: 136),
                      decoration: BoxDecoration(color: const Color(0xffF6F8FA), borderRadius: BorderRadius.circular(20)),
                      child: Padding(
                        padding: const EdgeInsets.all(8.0),
                        child: Column(
                          children: [
                            Row(
                              mainAxisAlignment: MainAxisAlignment.spaceBetween,
                              children: [
                                Row(
                                  children: [
                                    Container(
                                        constraints: const BoxConstraints(minHeight: 40, minWidth: 40),
                                        decoration: const BoxDecoration(shape: BoxShape.circle),
                                        child: const Icon(
                                          Icons.person,
                                          color: Color(0xffFB6F3D),
                                        )),
                                    const SizedBox(
                                      width: 14,
                                    ),
                                    const Text(
                                      'Personal Info',
                                      style: TextStyle(fontSize: 16, color: Color(0xff32343E), fontWeight: FontWeight.w400),
                                    )
                                  ],
                                ),
                                IconButton(onPressed: () {
                                  Navigator.push(context, MaterialPageRoute(builder:(context) => const PersonalInfoScreen(),));
                                }, icon: const Icon(Icons.arrow_forward_ios_outlined, color: Color(0xff747783)))
                              ],
                            ),
                            const SizedBox(
                              height: 16,
                            ),
                            Row(
                              mainAxisAlignment: MainAxisAlignment.spaceBetween,
                              children: [
                                Row(
                                  children: [
                                    Container(
                                        constraints: const BoxConstraints(minHeight: 40, minWidth: 40),
                                        decoration: const BoxDecoration(shape: BoxShape.circle),
                                        child: const Icon(
                                          Icons.map,
                                          color: Color(0xff413DFB),
                                        )),
                                    const SizedBox(
                                      width: 14,
                                    ),
                                    const Text(
                                      'Addresses',
                                      style: TextStyle(fontSize: 16, color: Color(0xff32343E), fontWeight: FontWeight.w400),
                                    )
                                  ],
                                ),
                                IconButton(onPressed: () {
                                  Navigator.push(context, MaterialPageRoute(builder: (context) => const AddressScreen(),));
                                }, icon: const Icon(Icons.arrow_forward_ios_outlined, color: Color(0xff747783)))
                              ],
                            ),
                          ],
                        ),
                      ),
                    ),
                    const SizedBox(
                      height: 20,
                    ),
                    Container(
                      width: MediaQuery.of(context).size.width,
                      constraints: const BoxConstraints(minHeight: 248),
                      decoration: BoxDecoration(color: const Color(0xffF6F8FA), borderRadius: BorderRadius.circular(20)),
                      child: Padding(
                        padding: const EdgeInsets.all(8.0),
                        child: Column(
                          children: [
                            Row(
                              mainAxisAlignment: MainAxisAlignment.spaceBetween,
                              children: [
                                Row(
                                  children: [
                                    Container(
                                        constraints: const BoxConstraints(minHeight: 40, minWidth: 40),
                                        decoration:  const BoxDecoration(shape: BoxShape.circle),
                                        child: const Icon(
                                          Icons.card_travel_outlined,
                                          color: Color(0xff369BFF),
                                        )),
                                    const SizedBox(
                                      width: 14,
                                    ),
                                    const Text(
                                      'Cart',
                                      style: TextStyle(fontSize: 16, color: Color(0xff32343E), fontWeight: FontWeight.w400),
                                    )
                                  ],
                                ),
                                IconButton(onPressed: () {}, icon: const Icon(Icons.arrow_forward_ios_outlined, color: Color(0xff747783)))
                              ],
                            ),
                            const SizedBox(
                              height: 16,
                            ),
                            Row(
                              mainAxisAlignment: MainAxisAlignment.spaceBetween,
                              children: [
                                Row(
                                  children: [
                                    Container(
                                        constraints:const BoxConstraints(minHeight: 40, minWidth: 40),
                                        decoration: const BoxDecoration(shape: BoxShape.circle),
                                        child: const Icon(
                                          Icons.favorite_border_outlined,
                                          color: Color(0xffB33DFB),
                                        )),
                                    const SizedBox(
                                      width: 14,
                                    ),
                                    const Text(
                                      'Favorite',
                                      style: TextStyle(fontSize: 16, color: Color(0xff32343E), fontWeight: FontWeight.w400),
                                    )
                                  ],
                                ),
                                IconButton(onPressed: () {}, icon: const Icon(Icons.arrow_forward_ios_outlined, color: Color(0xff747783)))
                              ],
                            ),
                            const SizedBox(
                              height: 16,
                            ),
                            Row(
                              mainAxisAlignment: MainAxisAlignment.spaceBetween,
                              children: [
                                Row(
                                  children: [
                                    Container(
                                        constraints: const BoxConstraints(minHeight: 40, minWidth: 40),
                                        decoration: const BoxDecoration(shape: BoxShape.circle),
                                        child: const Icon(
                                          Icons.notifications_none_outlined,
                                          color: Color(0xffFFAA2A),
                                        )),
                                    const SizedBox(
                                      width: 14,
                                    ),
                                    const Text(
                                      'Notifications',
                                      style: TextStyle(fontSize: 16, color: Color(0xff32343E), fontWeight: FontWeight.w400),
                                    )
                                  ],
                                ),
                                IconButton(onPressed: () {}, icon: const Icon(Icons.arrow_forward_ios_outlined, color: Color(0xff747783)))
                              ],
                            ),
                            const SizedBox(
                              height: 16,
                            ),
                            Row(
                              mainAxisAlignment: MainAxisAlignment.spaceBetween,
                              children: [
                                Row(
                                  children: [
                                    Container(
                                        constraints: const BoxConstraints(minHeight: 40, minWidth: 40),
                                        decoration: const BoxDecoration(shape: BoxShape.circle),
                                        child: const Icon(
                                          Icons.wallet,
                                          color: Color(0xff369BFF),
                                        )),
                                    const SizedBox(
                                      width: 14,
                                    ),
                                    const Text(
                                      'Payment Method',
                                      style: TextStyle(fontSize: 16, color: Color(0xff32343E), fontWeight: FontWeight.w400),
                                    )
                                  ],
                                ),
                                IconButton(onPressed: () {}, icon: const Icon(Icons.arrow_forward_ios_outlined, color: Color(0xff747783)))
                              ],
                            ),
                          ],
                        ),
                      ),
                    ),
                    const SizedBox(
                      height: 20,
                    ),
                    Container(
                      width: MediaQuery.of(context).size.width,
                      constraints: const BoxConstraints(minHeight: 248),
                      decoration: BoxDecoration(color: const Color(0xffF6F8FA), borderRadius: BorderRadius.circular(20)),
                      child: Padding(
                        padding: const EdgeInsets.all(8.0),
                        child: Column(
                          children: [
                            Row(
                              mainAxisAlignment: MainAxisAlignment.spaceBetween,
                              children: [
                                Row(
                                  children: [
                                    Container(
                                        constraints: const BoxConstraints(minHeight: 40, minWidth: 40),
                                        decoration:const BoxDecoration(shape: BoxShape.circle),
                                        child: const Icon(
                                          Icons.question_mark,
                                          color: Color(0xffFB6D3A),
                                        )),
                                    const SizedBox(
                                      width: 14,
                                    ),
                                    const Text(
                                      'FAQs',
                                      style: TextStyle(fontSize: 16, color: Color(0xff32343E), fontWeight: FontWeight.w400),
                                    )
                                  ],
                                ),
                                IconButton(onPressed: () {}, icon: const Icon(Icons.arrow_forward_ios_outlined, color: Color(0xff747783)))
                              ],
                            ),
                            const SizedBox(
                              height: 16,
                            ),
                            Row(
                              mainAxisAlignment: MainAxisAlignment.spaceBetween,
                              children: [
                                Row(
                                  children: [
                                    Container(
                                        constraints: const BoxConstraints(minHeight: 40, minWidth: 40),
                                        decoration: const BoxDecoration(shape: BoxShape.circle),
                                        child: const Icon(
                                          Icons.qr_code_scanner_outlined,
                                          color: Color(0xff2AE1E1),
                                        )),
                                    const SizedBox(
                                      width: 14,
                                    ),
                                    const Text(
                                      'User Reviews',
                                      style: TextStyle(fontSize: 16, color: Color(0xff32343E), fontWeight: FontWeight.w400),
                                    )
                                  ],
                                ),
                                IconButton(onPressed: () {}, icon: const Icon(Icons.arrow_forward_ios_outlined, color: Color(0xff747783)))
                              ],
                            ),
                            const SizedBox(
                              height: 16,
                            ),
                            Row(
                              mainAxisAlignment: MainAxisAlignment.spaceBetween,
                              children: [
                                Row(
                                  children: [
                                    Container(
                                        constraints: const BoxConstraints(minHeight: 40, minWidth: 40),
                                        decoration:  const BoxDecoration(shape: BoxShape.circle),
                                        child: const Icon(
                                          Icons.settings,
                                          color: Color(0xff413DFB),
                                        )),
                                    const SizedBox(
                                      width: 14,
                                    ),
                                    const Text(
                                      'Settings',
                                      style: TextStyle(fontSize: 16, color: Color(0xff32343E), fontWeight: FontWeight.w400),
                                    )
                                  ],
                                ),
                                IconButton(onPressed: () {}, icon: const Icon(Icons.arrow_forward_ios_outlined, color: Color(0xff747783)))
                              ],
                            ),
                          ],
                        ),
                      ),
                    ),
                    const SizedBox(
                      height: 20,
                    ),
                    Container(
                      width: MediaQuery.of(context).size.width,
                      constraints:const BoxConstraints(minHeight: 80),
                      decoration: BoxDecoration(color: const Color(0xffF6F8FA), borderRadius: BorderRadius.circular(20)),
                      child: Padding(
                        padding: const EdgeInsets.all(8.0),
                        child: Column(
                          children: [
                            Row(
                              mainAxisAlignment: MainAxisAlignment.spaceBetween,
                              children: [
                                Row(
                                  children: [
                                    Container(
                                        constraints: const BoxConstraints(minHeight: 40, minWidth: 40),
                                        decoration: const BoxDecoration(shape: BoxShape.circle),
                                        child: const Icon(
                                          Icons.quiz_outlined,
                                          color: Color(0xffFB4A59),
                                        )),
                                    const SizedBox(
                                      width: 14,
                                    ),
                                    const Text(
                                      'Log Out',
                                      style: TextStyle(fontSize: 16, color: Color(0xff32343E), fontWeight: FontWeight.w400),
                                    )
                                  ],
                                ),
                                IconButton(
                                    onPressed: () {},
                                    icon: const Icon(
                                      Icons.arrow_forward_ios_outlined,
                                      color: Color(0xff747783),
                                    ))
                              ],
                            ),
                          ],
                        ),
                      ),
                    ),
                  ],
                ),
              ),
            ),
          ),
        ),
        body: SafeArea(
          child: SingleChildScrollView(
            child: Column(
              children: [
                const SizedBox(
                  height: 24,
                ),
                Padding(
                  padding: const EdgeInsets.symmetric(horizontal: 24),
                  child: Row(
                    mainAxisAlignment: MainAxisAlignment.spaceBetween,
                    children: [
                      Row(
                        children: [
                          InkWell(
                            onTap: () {
                              _scaffoldKey.currentState?.openDrawer();
                            },
                            child: Container(
                               constraints: const BoxConstraints(minHeight: 45,minWidth: 45),
                                decoration:const BoxDecoration(color: Color(0xffECF0F4), shape: BoxShape.circle),
                                child: IconButton(
                                    onPressed: () {
                                      setState(() {
                                        _scaffoldKey.currentState?.openDrawer();
                                      });

                                      // Navigator.push(
                                      //     context,
                                      //     MaterialPageRoute(
                                      //       builder: (context) => (),
                                      //     ));
                                    },
                                    icon: const Icon(Icons.menu_outlined))),
                          ),
                          const SizedBox(
                            width: 16,
                          ),
                          const Text(
                            'DELIVER TO',
                            style: TextStyle(color: Color(0xffFC6E2A), fontSize: 15, fontWeight: FontWeight.w700),
                          ),
                        ],
                      ),
                      Container(
                        constraints: const BoxConstraints(minWidth: 45,minHeight: 45),
                        // margin: EdgeInsets.symmetric(horizontal: 24),

                        decoration: const BoxDecoration(color: Color(0xff181C2E), shape: BoxShape.circle),
                        child: IconButton(
                          icon: const Icon(
                            Icons.card_travel_outlined,
                            color: Colors.white,
                          ),
                          onPressed: () {},
                        ),
                      ),
                    ],
                  ),
                ),
                const SizedBox(
                  height: 24,
                ),
                const Padding(
                  padding: EdgeInsets.symmetric(horizontal: 24),
                  child: Row(
                    children: [
                      Text(
                        'Hey Halal, ',
                        style: TextStyle(fontSize: 16),
                      ),
                      Text(
                        'Good Afternoon!',
                        style: TextStyle(fontSize: 16, fontWeight: FontWeight.w700),
                      ),
                    ],
                  ),
                ),
                const SizedBox(
                  height: 16,
                ),
                Padding(
                  padding: const EdgeInsets.symmetric(horizontal: 24.0),
                  child: TextFormField(
                    keyboardAppearance: null,
                    onTap: () {
                      Navigator.push(context, MaterialPageRoute(builder: (context) => const SearchBarScreen()));
                    },
                    decoration: InputDecoration(
                      contentPadding: const EdgeInsets.all(25),
                      filled: true,
                      fillColor: const Color(0xffF6F6F6),
                      hintStyle: const TextStyle(color: Color(0xff676767), fontWeight: FontWeight.w400, fontSize: 15),
                      hintText: 'Search dishes, restaurants',
                      prefixIcon: const Icon(
                        Icons.search,
                        color: Color(0xffA0A5BA),
                        size: 30,
                      ),
                      border: OutlineInputBorder(
                        borderSide: BorderSide.none,
                        borderRadius: BorderRadius.circular(12),
                      ),
                    ),
                  ),
                ),
                const SizedBox(
                  height: 32,
                ),
                Padding(
                  padding: const EdgeInsets.symmetric(horizontal: 24.0),
                  child: Row(
                    mainAxisAlignment: MainAxisAlignment.spaceBetween,
                    children: [
                      const Text(
                        'All Categories',
                        style: TextStyle(color: Color(0xff32343E), fontSize: 20, fontWeight: FontWeight.w400),
                      ),
                      Row(
                        children: [
                          TextButton(
                              onPressed: () {},
                              child: const Text('See All', style: TextStyle(color: Color(0xff333333), fontSize: 16, fontWeight: FontWeight.w400))),
                          const Icon(
                            Icons.arrow_forward_ios_outlined,
                            color: Color(0xffA0A5BA),
                            size: 15,
                          )
                        ],
                      ),
                    ],
                  ),
                ),
                const SizedBox(height: 20),
                SizedBox(
                  height: 200,
                  child: ListView.separated(padding: const EdgeInsets.symmetric(horizontal: 24),
                      shrinkWrap: true,
                      scrollDirection: Axis.horizontal,
                      itemBuilder: (context, index) {
                        return Container(
                          height: 144,
                          width: 147,
                          decoration: BoxDecoration(
                            // boxShadow: [BoxShadow(blurRadius: 2,blurStyle: BlurStyle.outer)],
                            // color: Colors.yellow,
                            borderRadius: BorderRadius.circular(20),
                          ),
                          child: Padding(
                            padding: const EdgeInsets.all(8.0),
                            child: Column(
                              crossAxisAlignment: CrossAxisAlignment.start,
                              mainAxisAlignment: MainAxisAlignment.spaceAround,
                              children: [
                                Center(
                                  child: Container(
                                    height: 104,
                                    width: MediaQuery.of(context).size.width,
                                    decoration: BoxDecoration(
                                        borderRadius: BorderRadius.circular(20),
                                        // color: Colors.black,
                                        image: DecorationImage(
                                            image: AssetImage(
                                              categoryImage[index],
                                            ),
                                            fit: BoxFit.fitHeight)),
                                  ),
                                ),
                                Text(
                                  categoryName[index],
                                  style: const TextStyle(fontSize: 20, fontWeight: FontWeight.w700, color: Color(0xff32343E)),
                                ),
                                Row(
                                  mainAxisAlignment: MainAxisAlignment.spaceBetween,
                                  children: [
                                    const Text(
                                      'Starting',
                                      style: TextStyle(color: Color(0xff646982), fontSize: 15, fontWeight: FontWeight.w400),
                                    ),
                                    Text(categoryPrice[index])
                                  ],
                                )
                              ],
                            ),
                          ),
                        );
                      },
                      separatorBuilder: (context, index) {
                        return const SizedBox(
                          width: 10,
                        );
                      },
                      itemCount: categoryImage.length),
                ),
                const SizedBox(
                  height: 10,
                ),
                Padding(
                  padding: const EdgeInsets.symmetric(horizontal: 24.0),
                  child: Row(
                    mainAxisAlignment: MainAxisAlignment.spaceBetween,
                    children: [
                      const Text(
                        'Open Restaurants  ',
                        style: TextStyle(color: Color(0xff32343E), fontSize: 20, fontWeight: FontWeight.w400),
                      ),
                      Row(
                        children: [
                          TextButton(
                              onPressed: () {},
                              child: const Text('See All', style: TextStyle(color: Color(0xff333333), fontSize: 16, fontWeight: FontWeight.w400))),
                          const Icon(
                            Icons.arrow_forward_ios_outlined,
                            color: Color(0xffA0A5BA),
                            size: 15,
                          )
                        ],
                      ),
                    ],
                  ),
                ),
                const SizedBox(height: 20),
                SizedBox(height: 500,
                  child: ListView.separated(padding: const EdgeInsets.symmetric(horizontal: 24),
                      shrinkWrap: true,
                      scrollDirection: Axis.vertical,
                      itemBuilder: (context, index) {
                        return SizedBox(
                          // color: Colors.black,
                          // height: MediaQuery.of(context).size.height,
                          width: MediaQuery.of(context).size.width,
                          // color: Colors.red,
                          child: Column(
                            crossAxisAlignment: CrossAxisAlignment.start,
                            children: [
                              Container(
                                  height: 140,
                                  width: MediaQuery.of(context).size.width,
                                  decoration: BoxDecoration(
                                      borderRadius: BorderRadius.circular(10),
                                      image: DecorationImage(image: AssetImage(restoImage[index]), fit: BoxFit.cover))),
                              const SizedBox(
                                height: 8,
                              ),
                              Text(
                                restoNames[index],
                                style: const TextStyle(color: Color(0xff181C2E), fontSize: 20, fontWeight: FontWeight.w400),
                              ),
                              const SizedBox(
                                height: 5,
                              ),
                              Text(restoMenuItems[index], style: const TextStyle(color: Color(0xffA0A5BA), fontSize: 15, fontWeight: FontWeight.w400)),
                              const SizedBox(
                                height: 16,
                              ),
                              const Row(
                                children: [
                                  Row(
                                    children: [
                                      Icon(
                                        Icons.star_border_outlined,
                                        color: Color(0xffFF7622),
                                      ),
                                      Text(
                                        '4.7',
                                        style: TextStyle(color: Color(0xff181C2E), fontSize: 16, fontWeight: FontWeight.w700),
                                      )
                                    ],
                                  ),
                                  SizedBox(
                                    width: 24,
                                  ),
                                  Row(
                                    children: [
                                      Icon(
                                        Icons.fire_truck_outlined,
                                        color: Color(0xffFF7622),
                                      ),
                                      Text(
                                        '4.7',
                                        style: TextStyle(color: Color(0xff181C2E), fontSize: 14, fontWeight: FontWeight.w400),
                                      )
                                    ],
                                  ),
                                  SizedBox(
                                    width: 24,
                                  ),
                                  Row(
                                    children: [
                                      Icon(
                                        Icons.watch_later_outlined,
                                        color: Color(0xffFF7622),
                                      ),
                                      Text(
                                        '20 min',
                                        style: TextStyle(color: Color(0xff181C2E), fontSize: 14, fontWeight: FontWeight.w400),
                                      )
                                    ],
                                  ),
                                ],
                              )
                            ],
                          ),
                        );
                      },
                      separatorBuilder: (context, index) {
                        return const SizedBox(
                          height: 20,
                        );
                      },
                      itemCount: restoImage.length),
                ),
              ],
            ),
          ),
        ),
      );
    }
  }
