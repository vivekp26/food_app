import 'package:flutter/material.dart';
import 'package:food_delivery_app/HomeScreens/BurgerScreen.dart';

class BurgerBistroScreen extends StatefulWidget {
  const BurgerBistroScreen({super.key});

  @override
  State<BurgerBistroScreen> createState() => _BurgerBistroScreenState();
}

class _BurgerBistroScreenState extends State<BurgerBistroScreen> {
  List ingredientImage = [
    'assets/ingredient_1.png',
    'assets/ingredient_2.png',
    'assets/ingredient_3.png',
    'assets/ingredient_4.png',
    'assets/ingredient_5.png'
  ];
  int _counter = 0;

  void incrementCounter(){
    setState(() {
      _counter++;
      print('counter:$_counter');
    });
  }
  void decrementCounter(){
    if(_counter >0){
      setState(() {
        _counter--;
        print('counter:$_counter');
      });
    }}
  @override
  Widget build(BuildContext context) {
    return Scaffold(
      body: SizedBox(
        height: MediaQuery.of(context).size.height,
        child: SingleChildScrollView(
          child: Column(
            crossAxisAlignment: CrossAxisAlignment.start,
            children: [
              Column(
                children: [
                  Container(
                    constraints: const BoxConstraints(minHeight: 320),
                    // height: 320,
                    width: MediaQuery.of(context).size.width,
                    decoration: BoxDecoration(
                      color: const Color(0xffF58D1D),
                      borderRadius: BorderRadius.circular(30),
                      image: const DecorationImage(image: AssetImage('assets/popular_burger1-removebg-preview.png'),filterQuality: FilterQuality.high,fit: BoxFit.cover)
                    ),
                    child:  Align(alignment: Alignment.topLeft,
                      child: Padding(
                        padding: const EdgeInsets.symmetric(horizontal: 24,vertical: 50),
                        child: Row(
                          mainAxisAlignment: MainAxisAlignment.spaceBetween ,
                          children: [
                            Container(
                              constraints: const BoxConstraints(minHeight: 45,minWidth: 45),
                                decoration: const BoxDecoration(color: Color(0xffECF0F4), shape: BoxShape.circle),
                                child: IconButton(onPressed: () {
                                  Navigator.push(context, MaterialPageRoute(builder: (context) => BurgerScreen(),));
                                }, icon: const Icon(Icons.arrow_back_ios_outlined)
                                )
                            ),
                            Container(
                                constraints: const BoxConstraints(minHeight: 45,minWidth: 45),
                                decoration: const BoxDecoration(color: Color(0xffECF0F4), shape: BoxShape.circle),
                                child: IconButton(onPressed: () {
                                  // Navigator.push(context, MaterialPageRoute(builder: (context) => SearchBarScreen(),));
                                }, icon: const Icon(Icons.favorite_border_outlined,)
                                )
                            ),
                          ],
                        ),
                      ),
                    ),
                  )
                ],
              ),
              const SizedBox(height: 24,),
              Padding(
                padding: const EdgeInsets.symmetric(horizontal: 24),
                child: Column(crossAxisAlignment: CrossAxisAlignment.start,
                  children: [
                    const Text('Burger Bistro',style: TextStyle(color: Color(0xff181C2E),fontSize: 20,fontWeight: FontWeight.w400),),
                    const SizedBox(height: 10,),
                    Row(
                      children: [

                            Container(
                              constraints: const BoxConstraints(minWidth: 31,minHeight: 31),
                              // height: 31,
                              // width: 31,
                              decoration: const BoxDecoration(
                                shape: BoxShape.circle,
                                image: DecorationImage(image: AssetImage('assets/restoName_icon.png'),filterQuality: FilterQuality.high,fit: BoxFit.cover),
                              ),
                            ),
                        const SizedBox(width: 11,),
                        const Text('Rose Garden',style: TextStyle(fontSize: 17,color: Color(0xff181C2E),fontWeight: FontWeight.w400),)
                      ],
                    ),
                    const SizedBox(height: 20,),
                    const Row(
                      mainAxisAlignment: MainAxisAlignment.start,
                      children: [
                        Row(
                          children: [
                            Icon(Icons.star_border_outlined,color: Color(0xffFF7622),),
                            Text('4.7',style: TextStyle(color: Color(0xff181C2E),fontSize: 16,fontWeight: FontWeight.w700),)
                          ],
                        ),
                        SizedBox(width: 36,),
                        Row(
                          children: [
                            Icon(Icons.fire_truck_outlined,color: Color(0xffFF7622),),
                            SizedBox(width: 5,),
                            Text('Free',style: TextStyle(color: Color(0xff181C2E),fontSize: 14,fontWeight: FontWeight.w400),)
                          ],
                        ),
                        SizedBox(width: 36,),
                        Row(
                          children: [
                            Icon(Icons.watch_later_outlined,color: Color(0xffFF7622),),
                            SizedBox(width: 5,),
                            Text('20 min',style: TextStyle(color: Color(0xff181C2E),fontSize: 14,fontWeight: FontWeight.w400),)
                          ],
                        ),
                      ],
                    ),
                    const SizedBox(height: 20,),
                    const Text('Maecenas sed diam eget risus varius blandit sit amet non magna. Integer posuere erat a ante venenatis dapibus posuere velit aliquet.',style: TextStyle(fontSize: 14,fontWeight: FontWeight.w400,color: Color(0xffA0A5BA),)
                    ),
                    const SizedBox(height: 20,),
                    Row(mainAxisAlignment: MainAxisAlignment.start,
                      children: [
                        const Text('SIZE:',style: TextStyle(color: Color(0xff32343E),fontSize: 13,fontWeight: FontWeight.w400),),
                        const SizedBox(width: 16,),
                        InkWell(onTap: (){},
                          child: Container(
                            constraints: const BoxConstraints(minHeight: 48,minWidth: 48),
                            // height: 48,
                            // width: 48,
                            decoration: const BoxDecoration(
                                color: Color(0xffF0F5FA),
                                shape: BoxShape.circle
                            ),
                            child: const Center(child: Text('10”',style: TextStyle(color: Color(0xff121223),fontSize: 16,fontWeight: FontWeight.w400),)),
                          ),
                        ),
                        const SizedBox(width: 16,),
                        InkWell(onTap: (){},
                          child: Container(
                            constraints: const BoxConstraints(minHeight: 48,minWidth: 48),
                            // height: 48,
                            // width: 48,
                            decoration: const BoxDecoration(
                                color: Color(0xffF58D1D),
                                shape: BoxShape.circle
                            ),
                            child: const Center(child: Text('14”',style: TextStyle(color: Color(0xff121223),fontSize: 16,fontWeight: FontWeight.w400),)),
                          ),
                        ),
                        const SizedBox(width: 16,),
                        InkWell(onTap: (){},
                          child: Container(
                            constraints: const BoxConstraints(minHeight: 48,minWidth: 48),
                            // height: 48,
                            // width: 48,
                            decoration: const BoxDecoration(
                                color: Color(0xffF0F5FA),
                                shape: BoxShape.circle
                            ),
                            child: const Center(child: Text('16”',style: TextStyle(color: Color(0xff121223),fontSize: 16,fontWeight: FontWeight.w400),)),
                          ),
                        )
                      ],
                    ),
                    const SizedBox(height: 20,),
                    const Text('INGRIDENTS',style: TextStyle(color: Color(0xff32343E),fontSize: 13,fontWeight: FontWeight.w400),),
                    const SizedBox(height: 20,),
                    Row(
                      children: [
                        Container(
                          constraints: const BoxConstraints(minHeight: 50,minWidth: 50),
                          // height: 50,
                          // width: 50,
                          decoration: BoxDecoration(
                              color: const Color(0xffFFEBE4),
                              shape: BoxShape.circle,
                              image: DecorationImage(image: AssetImage(ingredientImage[0]),filterQuality: FilterQuality.high)
                          ),
                        ),
                        const SizedBox(width: 20,),
                        Container(
                          constraints: const BoxConstraints(minHeight: 50,minWidth: 50),
                          // height: 50,
                          // width: 50,
                          decoration: BoxDecoration(
                              color: const Color(0xffFFEBE4),
                              shape: BoxShape.circle,
                              image: DecorationImage(image: AssetImage(ingredientImage[1]),filterQuality: FilterQuality.high)
                          ),
                        ),
                        const SizedBox(width: 20,),
                        Container(
                          constraints: const BoxConstraints(minHeight: 50,minWidth: 50),
                          // height: 50,
                          // width: 50,
                          decoration: BoxDecoration(
                              color: const Color(0xffFFEBE4),
                              shape: BoxShape.circle,
                              image: DecorationImage(image: AssetImage(ingredientImage[2]),filterQuality: FilterQuality.high)
                          ),
                        ),
                        const SizedBox(width: 20,),
                        Container(
                          constraints: const BoxConstraints(minHeight: 50,minWidth: 50),
                          // height: 50,
                          // width: 50,
                          decoration: BoxDecoration(
                              color: const Color(0xffFFEBE4),
                              shape: BoxShape.circle,
                              image: DecorationImage(image: AssetImage(ingredientImage[3]),filterQuality: FilterQuality.high)
                          ),
                        ),
                        const SizedBox(width: 20,),
                        Container(
                          constraints: const BoxConstraints(minHeight: 50,minWidth: 50),
                          // height: 50,
                          // width: 50,
                          decoration: BoxDecoration(
                              color: const Color(0xffFFEBE4),
                              shape: BoxShape.circle,
                              image: DecorationImage(image: AssetImage(ingredientImage[4]),filterQuality: FilterQuality.high)
                          ),
                        )
                      ],
                    )
                  ],
                ),
              ),
              Container(
                constraints: const BoxConstraints(minHeight: 184),
                // height: 184,
                width: MediaQuery.of(context).size.width,
                decoration: const BoxDecoration(
                    color:Color(0XFFF0F5FA),
                    borderRadius: BorderRadius.only(topLeft: Radius.circular(30),topRight: Radius.circular(30))
                ),
                child: Padding(
                  padding: const EdgeInsets.all(27),
                  child: Column(
                    children: [
                      Row(
                        mainAxisAlignment: MainAxisAlignment.spaceBetween,
                        children: [
                          const Text('\$32',style: TextStyle(color: Color(0xff181C2E),fontSize: 28,fontWeight: FontWeight.w400),),
                          Container(
                            constraints: const BoxConstraints(minHeight: 50,minWidth: 125),
                            // height: 50,
                            // width: 125,
                            decoration: BoxDecoration(
                                color: const Color(0xff121223),
                                borderRadius: BorderRadius.circular(30)
                            ),
                            child: Row(mainAxisAlignment: MainAxisAlignment.spaceAround,
                              children: [
                                InkWell(onTap: decrementCounter,

                                  child: Container(
                                    height: 24,
                                    width: 24,
                                    decoration: const BoxDecoration(
                                      color: Colors.grey,
                                      shape: BoxShape.circle,
                                    ),
                                    child: const Icon(Icons.remove,color: Colors.white,),
                                  ),
                                ),
                                Text(_counter.toString(),style: const TextStyle(fontSize: 16,fontWeight: FontWeight.w700,color: Colors.white),),
                                InkWell(
                                  onTap: incrementCounter,
                                  child: Container(
                                    constraints: const BoxConstraints(minHeight: 24,minWidth: 24),
                                    // height: 24,
                                    // width: 24,
                                    decoration: const BoxDecoration(
                                      color: Colors.grey,
                                      shape: BoxShape.circle,
                                    ),
                                    child: const Icon(Icons.add,color: Colors.white,),
                                  ),
                                )
                              ],
                            ),
                          )
                        ],
                      ),
                      const SizedBox(height: 20,),
                      Container(
                          constraints: const BoxConstraints(minHeight: 60),
                          // height: 60,
                          width:MediaQuery.of(context).size.width,
                          child: ElevatedButton(style: ButtonStyle(backgroundColor: const MaterialStatePropertyAll(Color(0xffFF7622)),shape: MaterialStatePropertyAll(RoundedRectangleBorder(borderRadius: BorderRadius.circular(15)))),
                              onPressed: (){}, child: const Text('ADD TO CART',style: TextStyle(color: Colors.white,fontSize: 16,fontWeight: FontWeight.w400),)))
                    ],
                  ),
                ),
              )
            ],
          ),
        ),
      ),
    );
  }
}
