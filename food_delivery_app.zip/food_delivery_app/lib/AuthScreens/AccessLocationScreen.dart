import 'package:flutter/material.dart';
import 'package:food_delivery_app/HomeScreens/HomePage.dart';

class AccessLocation extends StatefulWidget {
  const AccessLocation({super.key});

  @override
  State<AccessLocation> createState() => _AccessLocationState();
}

class _AccessLocationState extends State<AccessLocation> {
  @override
  Widget build(BuildContext context) {
    return Scaffold(
      body: Padding(
        padding: const EdgeInsets.all(24),
        child: Column(
          mainAxisAlignment: MainAxisAlignment.center,
          children: [
            Center(
              child: Container(
                height: 250,
                width: 200,
                decoration: BoxDecoration(
                    borderRadius: BorderRadius.circular(80),
                    image: const DecorationImage(image: AssetImage('assets/location_logo2.jpg'), fit: BoxFit.cover)),
              ),
            ),
            const SizedBox(
              height: 90,
            ),
            SizedBox(
                height: 62,
                width: MediaQuery.of(context).size.width,
                child: OutlinedButton(
                    style: ButtonStyle(
                        shape: MaterialStatePropertyAll(RoundedRectangleBorder(borderRadius: BorderRadius.circular(20))),
                        backgroundColor: const MaterialStatePropertyAll(Color(0xffFF7622))),
                    onPressed: () {
                      Navigator.push(
                          context,
                          MaterialPageRoute(
                            builder: (context) => const HomePage(),
                          ));
                    },
                    child: const Row(
                      mainAxisAlignment: MainAxisAlignment.center,
                      children: [
                        Text(
                          'ACCESS LOCATION',
                          style: TextStyle(color: Colors.white, fontSize: 16, fontWeight: FontWeight.w700),
                        ),
                        SizedBox(
                          width: 24,
                        ),
                        Icon(
                          Icons.share_location,
                          color: Colors.white,
                          size: 25,
                        )
                      ],
                    ))),
            const SizedBox(
              height: 36,
            ),
            const Text(
              'DFOOD WILL ACCESS YOUR LOCATION ',
              style: TextStyle(color: Color(0xff646982), fontSize: 18, fontWeight: FontWeight.w400),
            ),
            const Text(
              'ONLY WHILE USING THE APP ',
              style: TextStyle(color: Color(0xff646982), fontSize: 18, fontWeight: FontWeight.w400),
            ),
          ],
        ),
      ),
    );
  }
}
