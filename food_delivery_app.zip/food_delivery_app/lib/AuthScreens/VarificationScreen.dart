import 'dart:async';

import 'package:flutter/material.dart';
import 'package:food_delivery_app/AuthScreens/AccessLocationScreen.dart';
import 'package:food_delivery_app/AuthScreens/ForgotPasswordScreen.dart';
import 'package:pinput/pinput.dart';

class VarificationScreen extends StatefulWidget {
  const VarificationScreen({super.key});

  @override
  State<VarificationScreen> createState() => _VarificationScreenState();
}

class _VarificationScreenState extends State<VarificationScreen> {
  TextEditingController pinController = TextEditingController();
  late Timer _timer;
  int start = 60;
  bool isResendActive = false;

  @override
  void initState() {
    // TODO: implement initState
    super.initState();
    startTimer();
  }

  void startTimer() {
    start = 60;
    isResendActive = true;
    _timer = Timer.periodic(const Duration(seconds: 1), (timer) {
      setState(() {
        if (start > 0) {
          start--;
        } else {
          _timer.cancel();
          isResendActive = true;
        }
      });
    });
  }

  @override
  void dispose() {
    _timer.cancel();
    super.dispose();
  }

  void onResendTimer() {
    if (isResendActive) {
      startTimer(); // Restart the timer when "Resend" is clicked
      setState(() {
        // Reset the resend button to disabled
        isResendActive = false;
        start = 60; // Reset the timer
      });
      // Add your resend logic here, like sending a new verification code
      print('Resend code logic triggered');
    }
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
        backgroundColor: Colors.black,
        body: SizedBox(
          height: MediaQuery.of(context).size.height,
          width: MediaQuery.of(context).size.width,
          child: Column(
            crossAxisAlignment: CrossAxisAlignment.center,
            children: [
              const SizedBox(
                height: 50,
              ),
              Align(
                alignment: Alignment.topLeft,
                child: Padding(
                  padding: const EdgeInsets.symmetric(horizontal: 24.0),
                  child: InkWell(
                    onTap: () {
                      Navigator.push(
                          context,
                          MaterialPageRoute(
                            builder: (context) => const ForgotPassword(),
                          ));
                    },
                    child: Container(
                      margin: const EdgeInsets.symmetric(horizontal: 15),
                      height: 45,
                      width: 45,
                      decoration: const BoxDecoration(shape: BoxShape.circle, color: Colors.white),
                      child: const Icon(Icons.arrow_back_ios_outlined),
                    ),
                  ),
                ),
              ),
              const SizedBox(
                height: 24,
              ),
              const Text(
                'Verification',
                style: TextStyle(fontSize: 30, fontWeight: FontWeight.w700, color: Colors.white),
              ),
              const SizedBox(
                height: 3,
              ),
              const Text(
                'We have sent a code to your email',
                style: TextStyle(fontSize: 16, fontWeight: FontWeight.w400, color: Colors.white),
              ),
              const SizedBox(
                height: 50,
              ),
              Flexible(
                child: Container(
                  height: MediaQuery.of(context).size.height,
                  decoration: const BoxDecoration(
                      borderRadius: BorderRadius.only(topLeft: Radius.circular(30), topRight: Radius.circular(30)), color: Colors.white),
                  child: SingleChildScrollView(
                    child: Padding(
                      padding: const EdgeInsets.all(24.0),
                      child: Column(
                        crossAxisAlignment: CrossAxisAlignment.start,
                        children: [
                          // SizedBox(
                          //   height: 24,
                          // ),
                          Row(
                            mainAxisAlignment: MainAxisAlignment.spaceBetween,
                            children: [
                              const Text(
                                'CODE',
                                style: TextStyle(fontSize: 16, fontWeight: FontWeight.w400, color: Color(0xff32343E)),
                              ),
                              Row(
                                children: [
                                  TextButton(
                                      onPressed: () {
                                        isResendActive ? onResendTimer() : null;
                                      },
                                      child: Text(
                                        'Resend',
                                        style:
                                            TextStyle(fontSize: 16, color: isResendActive ? Colors.black : Colors.grey, fontWeight: FontWeight.w700),
                                      )),
                                  Text(
                                    'in.$start sec',
                                    style: const TextStyle(fontSize: 15, color: Colors.black, fontWeight: FontWeight.w700),
                                  ),
                                ],
                              ),
                            ],
                          ),
                          const SizedBox(
                            height: 8,
                          ),
                          Pinput(
                            mainAxisAlignment: MainAxisAlignment.spaceEvenly,
                            controller: pinController,
                            length: 4,
                            defaultPinTheme: PinTheme(
                              width: 62,
                              height: 62,
                              textStyle: const TextStyle(
                                fontSize: 20,
                                color: Colors.black,
                                fontWeight: FontWeight.w600,
                              ),
                              decoration: BoxDecoration(
                                color: const Color(0xffF0F5FA),
                                borderRadius: BorderRadius.circular(10),
                              ),
                            ),
                            onCompleted: (pin) {
                              print('Entered PIN: $pin');
                            },
                          ),
                          const SizedBox(
                            height: 30,
                          ),
                          SizedBox(
                              height: 62,
                              width: MediaQuery.of(context).size.width,
                              child: OutlinedButton(
                                  style: ButtonStyle(
                                      shape: MaterialStatePropertyAll(RoundedRectangleBorder(borderRadius: BorderRadius.circular(20))),
                                      backgroundColor: const MaterialStatePropertyAll(Color(0xffFF7622))),
                                  onPressed: () {
                                    Navigator.push(
                                        context,
                                        MaterialPageRoute(
                                          builder: (context) => const AccessLocation(),
                                        ));
                                  },
                                  child: const Text(
                                    'SEND CODE',
                                    style: TextStyle(color: Colors.white, fontSize: 14, fontWeight: FontWeight.w700),
                                  ))),
                        ],
                      ),
                    ),
                  ),
                ),
              )
            ],
          ),
        ));
  }
}
