import 'dart:async';

import 'package:flutter/material.dart';
import 'package:food_delivery_app/AuthScreens/LoginScreen.dart';

class DashBoardScreen extends StatefulWidget {
  const DashBoardScreen({super.key});

  @override
  State<DashBoardScreen> createState() => _DashBoardScreenState();
}

class _DashBoardScreenState extends State<DashBoardScreen> {
  List pageViewImage = ['assets/pageview_image1.jpg', 'assets/pageview_image2.jpg', 'assets/Pageview_image3.jpg', 'assets/pageview_image4.jpg'];
  List mainTitle = [
    'All your favorites',
    'All your favorites',
    'Order from choosen chef',
    'Free delivery offers',
  ];
  List title = [
    'Get all your loved foods in one once place,',
    'Get all your loved foods in one once place,',
    'Get all your loved foods in one once place,',
    'Get all your loved foods in one once place,',
  ];
  List subTitle = [
    'you just place the orer we do the rest',
    'you just place the orer we do the rest',
    'you just place the orer we do the rest',
    'you just place the orer we do the rest',
  ];
  PageController _pageController = PageController();
  Widget indicator(int index) {
    return Padding(
      padding: const EdgeInsets.all(8.0),
      child: Container(
        height: 10,
        width: currentIndex == index ? 15 : 10,
        decoration: BoxDecoration(borderRadius: BorderRadius.circular(20), color: currentIndex == index ? Colors.deepOrange : Colors.orangeAccent),
      ),
    );
  }

  int currentIndex = 0;
  @override
  Widget build(BuildContext context) {
    return Scaffold(
      body: SingleChildScrollView(
        child: Padding(
          padding: const EdgeInsets.all(10),
          child: Column(
            children: [
              Column(children: [
                SizedBox(
                  // color: Colors.red,
                  height: 675,
                  child: PageView.builder(
                    controller: _pageController,
                    scrollDirection: Axis.horizontal,
                    itemCount: pageViewImage.length,
                    onPageChanged: (index) {
                      setState(() {
                        currentIndex = index;

                        // Navigator.push(context, MaterialPageRoute(builder: (context) => ));
                      });
                    },
                    itemBuilder: (context, index) {
                      return Column(
                        mainAxisAlignment: MainAxisAlignment.center,
                        children: [
                          Container(
                            height: 292,
                            width: 240,
                            decoration: BoxDecoration(
                                borderRadius: BorderRadius.circular(20),
                                image:
                                    DecorationImage(image: AssetImage(pageViewImage[index]), filterQuality: FilterQuality.high, fit: BoxFit.cover)),
                          ),
                          const SizedBox(
                            height: 63,
                          ),
                          Text(
                            mainTitle[index],
                            style: const TextStyle(color: Color(0xff32343E), fontSize: 24, fontWeight: FontWeight.w800),
                          ),
                          const SizedBox(
                            height: 18,
                          ),
                          Text(
                            title[index],
                            style: const TextStyle(color: Color(0xff646982), fontSize: 16, fontWeight: FontWeight.w400),
                          ),
                          Text(
                            subTitle[index],
                            style: const TextStyle(color: Color(0xff646982), fontSize: 16, fontWeight: FontWeight.w400),
                          ),
                          const SizedBox(
                            height: 32,
                          ),
                          Row(
                              mainAxisAlignment: MainAxisAlignment.center,
                              children: List.generate(pageViewImage.length, (index) {
                                return indicator(index);
                              })),
                        ],
                      );
                    },
                  ),
                ),
              ]),
              SizedBox(
                  height: 62,
                  width: MediaQuery.of(context).size.width,
                  child: OutlinedButton(
                      style: ButtonStyle(
                          shape: MaterialStatePropertyAll(RoundedRectangleBorder(borderRadius: BorderRadius.circular(20))),
                          backgroundColor: const MaterialStatePropertyAll(Color(0xffFF7622))),
                      onPressed: () {
                        _pageController.nextPage(duration: const Duration(microseconds: 800), curve: Curves.easeIn);
                        // Navigator.push(context, MaterialPageRoute(builder: (context) => ,));
                      },
                      child: const Text(
                        'NEXT',
                        style: TextStyle(color: Colors.white, fontSize: 24),
                      ))),
              const SizedBox(
                height: 16,
              ),
              TextButton(
                  onPressed: () {
                    Navigator.push(
                        context,
                        MaterialPageRoute(
                          builder: (context) => const LoginScreen(),
                        ));
                  },
                  child: const Text('Skip', style: TextStyle(color: Color(0xff646982), fontSize: 16, fontWeight: FontWeight.w400)))
            ],
          ),
        ),
      ),
    );
  }
}

class SplashScreen extends StatefulWidget {
  const SplashScreen({super.key});

  @override
  State<SplashScreen> createState() => _SplashScreenState();
}

class _SplashScreenState extends State<SplashScreen> {
  @override
  void initState() {
    // TODO: implement initState
    Timer(const Duration(seconds: 3), () {
      Navigator.push(context, MaterialPageRoute(builder: (context) => DashBoardScreen()));
    });
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      body: Center(
        child: Container(
          height: 150,
          width: 150,
          decoration: const BoxDecoration(
              image: DecorationImage(image: AssetImage('assets/splash_logo.png'), fit: BoxFit.contain, filterQuality: FilterQuality.high)),
        ),
      ),
    );
  }
}
