import 'package:flutter/material.dart';
import 'package:food_delivery_app/AuthScreens/ForgotPasswordScreen.dart';
import 'package:food_delivery_app/AuthScreens/SignUpScreen.dart';


class LoginScreen extends StatefulWidget {
  const LoginScreen({super.key});

  @override
  State<LoginScreen> createState() => _LoginScreenState();
}

class _LoginScreenState extends State<LoginScreen> {
  final _formkey = GlobalKey<FormState>();
  final TextEditingController _email = TextEditingController();
  final TextEditingController _password = TextEditingController();
  bool isPasswordVisible = false;
  bool isChecked = false;
  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: Colors.black,
      body: Container(
        height: MediaQuery.of(context).size.height,
        width: MediaQuery.of(context).size.width,
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.center,
          children: [
            const SizedBox(
              height: 118,
            ),
            const Text(
              'Log In',
              style: TextStyle(fontSize: 30, fontWeight: FontWeight.w700, color: Colors.white),
            ),
            const SizedBox(
              height: 3,
            ),
            const Text(
              'Please sign in to your existing account',
              style: TextStyle(fontSize: 16, fontWeight: FontWeight.w400, color: Colors.white),
            ),
            const SizedBox(
              height: 50,
            ),
            Flexible(
              child: Container(
                height: MediaQuery.of(context).size.height,
                decoration:
                const BoxDecoration(borderRadius: BorderRadius.only(topLeft: Radius.circular(30), topRight: Radius.circular(30)), color: Colors.white),
                child: SingleChildScrollView(
                  child: Form(
                    key: _formkey,
                    child: Padding(
                      padding: const EdgeInsets.all(24.0),
                      child: Column(
                        crossAxisAlignment: CrossAxisAlignment.start,
                        children: [
                          const SizedBox(
                            height: 24,
                          ),
                          const Text(
                            'EMAIL',
                            style: TextStyle(fontSize: 14, fontWeight: FontWeight.w400, color: Color(0xff32343E)),
                          ),
                          const SizedBox(
                            height: 8,
                          ),
                          TextFormField(
                            controller: _email,
                            validator: (value) {
                              bool emailValid = RegExp(r"^[a-zA-Z0-9.a-zA-Z0-9.!#$%&'*+-/=?^_`{|}~]+@[a-zA-Z0-9]+\.[a-zA-Z]+").hasMatch(value!);
                              if (value.isEmpty) {
                                return 'Enter Email';
                              }
                              if (!emailValid) {
                                return 'Enter Valid Email';
                              }
                            },
                            decoration: InputDecoration(
                                fillColor: const Color(0xffF0F5FA),
                                filled: true,
                                contentPadding: const EdgeInsets.all(20),
                                border: OutlineInputBorder(borderSide: BorderSide.none, borderRadius: BorderRadius.circular(10))),
                          ),
                          const SizedBox(
                            height: 24,
                          ),
                          const Text(
                            'PASSWORD',
                            style: TextStyle(fontSize: 14, fontWeight: FontWeight.w400, color: Color(0xff32343E)),
                          ),
                          const SizedBox(
                            height: 8,
                          ),
                          TextFormField(
                            controller: _password,
                            validator: (value) {
                              if (value == null || value.isEmpty) {
                                return 'Please Enter Password';
                              } else if (_password.text.length < 6) {
                                return 'Password Length must not be less than 6';
                              }
                            },
                            style: const TextStyle(color: Color(0xffA0A5BA), fontSize: 14, fontWeight: FontWeight.w400),
                            obscureText:!isPasswordVisible,
                            decoration: InputDecoration(
                                suffixIcon: IconButton(
                                    onPressed: () {
                                      setState(() {
                                        isPasswordVisible = !isPasswordVisible;
                                      });
                                    },
                                    icon: Icon(
                                      isPasswordVisible?

                                      Icons.visibility:Icons.visibility_off,
                                      color:const  Color(0xffB4B9CA),
                                    )),
                                fillColor: const Color(0xffF0F5FA),
                                filled: true,
                                contentPadding: const EdgeInsets.all(20),
                                border: OutlineInputBorder(borderSide: BorderSide.none, borderRadius: BorderRadius.circular(10))),
                          ),
                          const SizedBox(
                            height: 24,
                          ),
                          Row(
                            mainAxisAlignment: MainAxisAlignment.spaceBetween,
                            children: [
                              Row(
                                children: [
                                  Checkbox(
                                    value: isChecked,
                                    onChanged: (bool? value) {
                                      setState(() {
                                        isChecked = value ?? false;
                                      });
                                    },
                                  ),
                                  const Text(
                                    'Remember me',
                                    style: TextStyle(fontSize: 13, color: Color(0xff7E8A97), fontWeight: FontWeight.w400),
                                  ),
                                ],
                              ),
                              TextButton(
                                  onPressed: () {
                                    Navigator.push(context, MaterialPageRoute(builder: (context) => ForgotPassword()));
                                  },
                                  child: const Text(
                                    'Forgot Password',
                                    style: TextStyle(color: Color(0xffFF7622), fontSize: 14, fontWeight: FontWeight.w400),
                                  ))
                            ],
                          ),
                          const SizedBox(
                            height: 31,
                          ),
                          SizedBox(
                              height: 62,
                              width: MediaQuery.of(context).size.width,
                              child: OutlinedButton(
                                  style: ButtonStyle(
                                      shape: MaterialStatePropertyAll(RoundedRectangleBorder(borderRadius: BorderRadius.circular(20))),
                                      backgroundColor: const MaterialStatePropertyAll(Color(0xffFF7622))),
                                  onPressed: () {
                                    if (_formkey.currentState!.validate() ?? false) {
                                      if (isChecked) {
                                        ScaffoldMessenger.of(context).showSnackBar(
                                          const SnackBar(content: Text('Terms Accepted!')),
                                        );
                                      } else {
                                        ScaffoldMessenger.of(context).showSnackBar(const SnackBar(content: Text('Please Accept Rmember me!')));
                                      }
                                    }

                                    // Navigator.push(context, MaterialPageRoute(builder: (context) => ,));
                                  },
                                  child:const Text(
                                    'LOG IN',
                                    style: TextStyle(color: Colors.white, fontSize: 14, fontWeight: FontWeight.w700),
                                  ))),
                          const SizedBox(
                            height: 38,
                          ),
                          Row(
                            mainAxisAlignment: MainAxisAlignment.center,
                            children: [
                              const Text(
                                'Don’t have an account?',
                                style: TextStyle(color: Color(0xff646982), fontSize: 16, fontWeight: FontWeight.w400),
                              ),
                              // SizedBox(width: 10,),
                              TextButton(
                                  onPressed: () {
                                    Navigator.push(
                                        context,
                                        MaterialPageRoute(
                                          builder: (context) => SignUpScreen(),
                                        ));
                                  },
                                  child: const Text(
                                    'Sign Up',
                                    style: TextStyle(color: Color(0xffFF7622), fontSize: 14, fontWeight: FontWeight.w700),
                                  )),
                            ],
                          ),
                          const SizedBox(
                            height: 27,
                          ),
                          const Align(
                              alignment: Alignment.center,
                              child: Text(
                                'Or',
                                style: TextStyle(color: Color(0xff646982), fontSize: 16, fontWeight: FontWeight.w400),
                              )),
                          const SizedBox(
                            height: 15,
                          ),
                          Row(
                            mainAxisAlignment: MainAxisAlignment.center,
                            children: [
                              Container(
                                height: 60,
                                width: 60,
                                decoration: BoxDecoration(
                                    shape: BoxShape.circle,
                                    border: Border.all(color: Colors.black),
                                    image: const DecorationImage(image: AssetImage('assets/fb_logo.png'), fit: BoxFit.cover)),
                              ),
                              const SizedBox(
                                width: 30,
                              ),
                              Container(
                                height: 60,
                                width: 60,
                                decoration: BoxDecoration(
                                    shape: BoxShape.circle,
                                    border: Border.all(color: Colors.black),
                                    image: const DecorationImage(image: AssetImage('assets/twitter_logo.png'), fit: BoxFit.cover)),
                              ),
                              const SizedBox(
                                width: 30,
                              ),
                              Container(
                                height: 60,
                                width: 60,
                                decoration: BoxDecoration(
                                    shape: BoxShape.circle,
                                    border: Border.all(color: Colors.black),
                                    image: const DecorationImage(image: AssetImage('assets/apple_logo.png'), fit: BoxFit.cover)),
                              ),
                            ],
                          )
                        ],
                      ),
                    ),
                  ),
                ),
              ),
            )
          ],
        ),
      ),
    );
  }
}
