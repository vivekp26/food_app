import 'package:flutter/material.dart';
import 'package:food_delivery_app/AuthScreens/LoginScreen.dart';

class SignUpScreen extends StatefulWidget {
  const SignUpScreen({super.key});

  @override
  State<SignUpScreen> createState() => _SignUpScreenState();
}

class _SignUpScreenState extends State<SignUpScreen> {
  final _formkey = GlobalKey<FormState>();
  TextEditingController _name = TextEditingController();
  TextEditingController _email = TextEditingController();
  TextEditingController _password = TextEditingController();
  bool isPasswordVisible = false;
  @override
  Widget build(BuildContext context) {
    return Scaffold(
        backgroundColor: Colors.black,
        body: Form(
          key: _formkey,
          child: SizedBox(
            height: MediaQuery.of(context).size.height,
            width: MediaQuery.of(context).size.width,
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.center,
              children: [
                const SizedBox(
                  height: 50,
                ),
                Align(
                  alignment: Alignment.topLeft,
                  child: Padding(
                    padding: const EdgeInsets.symmetric(horizontal: 24.0),
                    child: InkWell(
                      onTap: () {
                        // Navigator.push(
                        //     context,
                        //     MaterialPageRoute(
                        //       builder: (context) => LoginScreen(),
                        //     ));
                        Navigator.pop(context);
                      },
                      child: Container(
                        margin: const EdgeInsets.symmetric(horizontal: 15),
                        height: 45,
                        width: 45,
                        decoration: const BoxDecoration(shape: BoxShape.circle, color: Colors.white),
                        child: const Icon(Icons.arrow_back_ios_outlined),
                      ),
                    ),
                  ),
                ),
                const SizedBox(
                  height: 24,
                ),
                const Text(
                  'Sign Up',
                  style: TextStyle(fontSize: 30, fontWeight: FontWeight.w700, color: Colors.white),
                ),
                const SizedBox(
                  height: 3,
                ),
                const Text(
                  'Please sign up to get started',
                  style: TextStyle(fontSize: 16, fontWeight: FontWeight.w400, color: Colors.white),
                ),
                const SizedBox(
                  height: 50,
                ),
                Flexible(
                  child: Container(
                    height: MediaQuery.of(context).size.height,
                    decoration: const BoxDecoration(
                        borderRadius: BorderRadius.only(topLeft: Radius.circular(30), topRight: Radius.circular(30)), color: Colors.white),
                    child: SingleChildScrollView(
                      child: Padding(
                        padding: const EdgeInsets.all(24.0),
                        child: Column(
                          crossAxisAlignment: CrossAxisAlignment.start,
                          children: [
                            const SizedBox(
                              height: 24,
                            ),
                            const Text(
                              'NAME',
                              style: TextStyle(fontSize: 14, fontWeight: FontWeight.w400, color: Color(0xff32343E)),
                            ),
                            const SizedBox(
                              height: 8,
                            ),
                            TextFormField(
                              controller: _name,
                              validator: (value) {
                                if (value!.isEmpty) {
                                  return 'Enter Name';
                                }
                              },
                              decoration: InputDecoration(
                                  fillColor: const Color(0xffF0F5FA),
                                  filled: true,
                                  contentPadding: const EdgeInsets.all(20),
                                  border: OutlineInputBorder(borderSide: BorderSide.none, borderRadius: BorderRadius.circular(10))),
                            ),
                            const SizedBox(
                              height: 24,
                            ),
                            const Text(
                              'EMAIL',
                              style: TextStyle(fontSize: 14, fontWeight: FontWeight.w400, color: Color(0xff32343E)),
                            ),
                            const SizedBox(
                              height: 8,
                            ),
                            TextFormField(
                              controller: _email,
                              validator: (value) {
                                bool emailValid = RegExp(r"^[a-zA-Z0-9.a-zA-Z0-9.!#$%&'*+-/=?^_`{|}~]+@[a-zA-Z0-9]+\.[a-zA-Z]+").hasMatch(value!);
                                if (value!.isEmpty) {
                                  return 'Enter Email';
                                }
                                if (!emailValid) {
                                  return 'Enter Valid Email';
                                }
                              },
                              decoration: InputDecoration(
                                  fillColor: const Color(0xffF0F5FA),
                                  filled: true,
                                  contentPadding: const EdgeInsets.all(20),
                                  border: OutlineInputBorder(borderSide: BorderSide.none, borderRadius: BorderRadius.circular(10))),
                            ),
                            const SizedBox(
                              height: 24,
                            ),
                            const Text(
                              'PASSWORD',
                              style: TextStyle(fontSize: 14, fontWeight: FontWeight.w400, color: Color(0xff32343E)),
                            ),
                            const SizedBox(
                              height: 8,
                            ),
                            TextFormField(
                              controller: _password,
                              validator: (value) {
                                if (value == null || value.isEmpty) {
                                  return 'Please Enter Password';
                                } else if (_password.text.length < 6) {
                                  return 'Password Length must not be less than 6';
                                }
                              },
                              style: const TextStyle(color: Color(0xffA0A5BA), fontSize: 14, fontWeight: FontWeight.w400),
                              obscureText: !isPasswordVisible,
                              decoration: InputDecoration(
                                  suffixIcon: IconButton(
                                      onPressed: () {
                                        setState(() {
                                          isPasswordVisible = !isPasswordVisible;
                                        });
                                      },
                                      icon: Icon(
                                        isPasswordVisible ?Icons.visibility:Icons.visibility_off,
                                        color: const Color(0xffB4B9CA),
                                      )),
                                  fillColor: const Color(0xffF0F5FA),
                                  filled: true,
                                  contentPadding: const EdgeInsets.all(20),
                                  border: OutlineInputBorder(borderSide: BorderSide.none, borderRadius: BorderRadius.circular(10))),
                            ),
                            const SizedBox(
                              height: 24,
                            ),
                            const Text(
                              'Re-Type Password',
                              style: TextStyle(fontSize: 14, fontWeight: FontWeight.w400, color: Color(0xff32343E)),
                            ),
                            const SizedBox(
                              height: 8,
                            ),
                            TextFormField(
                              controller: _password,
                              validator: (value) {
                                if (value == null || value.isEmpty) {
                                  return 'Please Re-Enter Password';
                                } else if (_password.text.length < 6) {
                                  return 'Password Length must not be less than 6';
                                }
                              },
                              style: const TextStyle(color: Color(0xffA0A5BA), fontSize: 14, fontWeight: FontWeight.w400),
                              obscureText: !isPasswordVisible,
                              decoration: InputDecoration(
                                  suffixIcon: IconButton(
                                      onPressed: () {
                                        setState(() {
                                          isPasswordVisible = !isPasswordVisible;
                                        });
                                      },
                                      icon: Icon(
                                          isPasswordVisible ?Icons.visibility:Icons.visibility_off,
                                        color: const Color(0xffB4B9CA),
                                      )),
                                  fillColor: const Color(0xffF0F5FA),
                                  filled: true,
                                  contentPadding: const EdgeInsets.all(20),
                                  border: OutlineInputBorder(borderSide: BorderSide.none, borderRadius: BorderRadius.circular(10))),
                            ),
                            const SizedBox(
                              height: 70,
                            ),
                            SizedBox(
                                height: 62,
                                width: MediaQuery.of(context).size.width,
                                child: OutlinedButton(
                                    style: ButtonStyle(
                                        shape: MaterialStatePropertyAll(RoundedRectangleBorder(borderRadius: BorderRadius.circular(20))),
                                        backgroundColor: const MaterialStatePropertyAll(Color(0xffFF7622))),
                                    onPressed: () {
                                      if(_formkey.currentState!.validate()){
                                        Navigator.push(
                                            context,
                                            MaterialPageRoute(
                                              builder: (context) => const LoginScreen(),
                                            ));
                                      }
                                      },
                                    child: const Text(
                                      'Sign Up',
                                      style: TextStyle(color: Colors.white, fontSize: 14, fontWeight: FontWeight.w700),
                                    ))),
                          ],
                        ),
                      ),
                    ),
                  ),
                )
              ],
            ),
          ),
        ));
  }
}
